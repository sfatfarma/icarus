<?php
/** 
Plugin Name: Icarus All In One Page Redirect Plugin for WordPress
Plugin URI: http://codecanyon.net/user/CodeRevolution/portfolio
Description: This plugin automatically redirects pages (with 301 redirect), by the rules you set in the plugin control panel.
Author: CodeRevolution
Version: 1.2
Author URI: https://codecanyon.net/user/CodeRevolution
*/
define('ICARUS_MAINTENANCE_CSS_PLAIN', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style.css');
define('ICARUS_MAINTENANCE_CSS_RED', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-red.css');
define('ICARUS_MAINTENANCE_CSS_GREEN', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-green.css');
define('ICARUS_MAINTENANCE_CSS_BLUE', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-blue.css');
define('ICARUS_MAINTENANCE_CSS_YELLOW', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-yellow.css');
define('ICARUS_MAINTENANCE_CSS_BLACK', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-black.css');
define('ICARUS_MAINTENANCE_CSS_WHITE', plugin_dir_url( __FILE__ ) . 'styles/icarus-maintenance-style-white.css');
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/icarus/master/info.json", __FILE__, "icarus-page-redirect");
add_action('admin_menu', 'icarus_register_my_custom_menu_page');
function icarus_register_my_custom_menu_page()
{
    add_menu_page('Icarus All In One Page Redirect', 'Icarus All In One Page Redirect', 'manage_options', 'icarus_admin_settings', 'icarus_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('icarus_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'icarus_admin_settings');
    add_submenu_page('icarus_admin_settings', 'View Logs', 'View Logs', 'manage_options', 'icarus_admin_logs', 'icarus_admin_logs');
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'icarus_add_settings_link');
add_shortcode('icarus_redirect', 'icarus_do_redirect');
function icarus_do_exit_link($atts)
{
	ob_start();
	$myURL = (isset($atts['url']) && !empty($atts['url']))?esc_url($atts['url']):"";
    $myTEXT = (isset($atts['text']) && !empty($atts['text']))?esc_attr($atts['text']):"";
	$mySEC = (isset($atts['timeout']) && !empty($atts['timeout']))?esc_attr($atts['timeout']):"-1";
    $myIMG = (isset($atts['image']) && !empty($atts['image']))?esc_attr($atts['image']):"-1";
    $myCOLOR = (isset($atts['color']) && !empty($atts['color']))?esc_attr($atts['color']):"-1";
    $myHOVER = (isset($atts['hover']) && !empty($atts['hover']))?esc_attr($atts['hover']):"-1";
    $myHTML = (isset($atts['html']) && !empty($atts['html']))?esc_attr($atts['html']):"-1";
    $myFB = (isset($atts['facebook']) && !empty($atts['facebook']))?esc_attr($atts['facebook']):"-1";
    $myTW = (isset($atts['twitter']) && !empty($atts['twitter']))?esc_attr($atts['twitter']):"-1";
    $myG = (isset($atts['google']) && !empty($atts['google']))?esc_attr($atts['google']):"-1";
    $myANCHOR = (isset($atts['anchor']) && !empty($atts['anchor']))?esc_attr($atts['anchor']):"";
	if(!empty($myURL) && !empty($myTEXT) && !empty($myANCHOR))
    {
?>
        <a href="<?php echo plugin_dir_url( __FILE__ ) . "res/icarus-exit-template.php?url=" . $myURL . "&text=".$myTEXT."&timeout=".$mySEC."&color=".$myCOLOR."&hover=".$myHOVER."&image=".$myIMG."&facebook=".$myFB."&twitter=".$myTW."&google=".$myG."&html=".$myHTML;?>"><?php echo $myANCHOR;?></a>
		
<?php
	}
	return ob_get_clean();
}

function icarus_add_ajaxurl() {

    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
add_action('wp_head', 'icarus_add_ajaxurl');
add_action('wp_ajax_icarus_my_action', 'icarus_my_action_callback');
function icarus_my_action_callback()
{
    $redirects = get_option('icarus_301_redirects');
    echo print_r($redirects, true);
    die();
}

add_shortcode('icarus_exit_link', 'icarus_do_exit_link');
function icarus_do_redirect($atts)
{
	ob_start();
	$myURL = (isset($atts['url']) && !empty($atts['url']))?esc_url($atts['url']):"";
	$mySEC = (isset($atts['timeout']) && !empty($atts['timeout']))?esc_attr($atts['timeout']):"0";
	if(!empty($myURL))
    {
?>
		<meta http-equiv="refresh" content="<?php echo $mySEC; ?>; url=<?php echo $myURL; ?>">
<?php
	}
	return ob_get_clean();
}

$icarus_Main_Settings = get_option('icarus_Main_Settings', false);
if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
{
    if(isset($icarus_Main_Settings['redirect_login']) && $icarus_Main_Settings['redirect_login'] === 'on')
    {
        if(isset($icarus_Main_Settings['redirect_login_link']) && $icarus_Main_Settings['redirect_login_link'] !== '')
        {
            add_filter('login_redirect', 'icarus_login_redirect', 10);
        }          
    }
    if(isset($icarus_Main_Settings['redirect_logout']) && $icarus_Main_Settings['redirect_logout'] === 'on')
    {
        if(isset($icarus_Main_Settings['redirect_logout_link']) && $icarus_Main_Settings['redirect_logout_link'] !== '')
        {
            add_filter('wp_logout', 'icarus_logout_redirect', 10);
        }  
    }
    if(isset($icarus_Main_Settings['redirect_comment']) && $icarus_Main_Settings['redirect_comment'] === 'on')
    {
        if(isset($icarus_Main_Settings['redirect_comment_link']) && $icarus_Main_Settings['redirect_comment_link'] !== '')
        {
            add_filter( 'comment_post_redirect', 'icarus_comment_redirect', 10, 2 );
        }
    }
}

function icarus_login_redirect(){
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    if(isset($icarus_Main_Settings['redirect_login_link']))
    {
        return $icarus_Main_Settings['redirect_login_link'];
    }
    else
    {
        return get_home_url();
    } 
}
function icarus_logout_redirect() 
{
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    if(isset($icarus_Main_Settings['redirect_logout_link']))
    {
        icarus_wp_redirect( $icarus_Main_Settings['redirect_logout_link'] );
    }
}

function icarus_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=icarus_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
function icarus_debug_to_console( $data ) {

    if ( is_array( $data ) )
        $output = "<script>console.log( 'Debug Objects: " . implode( ',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";

    echo $output;
}
register_activation_hook(__FILE__, 'icarus_activation_callback');
function icarus_activation_callback()
{
    $icarus_Main_Settings = array(
        'icarus_enabled' => 'on',
        'redirect_enable' => 'off',
        'redirect_404_enable' => 'off',
        'redirect_404_link' => '',
        'redirect_random' => 'off',
        'redirect_random_url' => '/random-post',
        'start_time' => '',
        'end_time' => '',
        'start_date' => '',
        'end_date' => '',
        'redirect_time_based' => 'off',
        'redirect_referrer_link' => '',
        'redirect_enable_referrer' => 'off',
        'redirect_username' => '', 
        'redirect_enable_username' => 'off',
        'redirect_os' => 'All',
        'redirect_enable_os' => 'off',
        'redirect_enable_log' => 'off',
        'redirect_logout_link' => '',
        'redirect_logout' => 'off',
        'redirect_login' => 'off',
        'redirect_login_link' => '',
        'redirect_maintenance_name' => '',
        'redirect_maintenance' => 'off',
        'redirect_maintenance_title' => '',
        'redirect_maintenance_style' => 'Plain',
        'redirect_maintenance_text_color' => '#000000',
        'redirect_maintenance_title_color' => '#000000',
        'redirect_attachment' => 'off',
        'redirect_comment_link' => '',
        'redirect_comment' => 'off',
        'redirect_http' => 'No',
        'redirect_www' => 'No',
        'redirect_adblock' => 'off',
        'redirect_adblock_link' => '',
        'redirect_clear_log' => 'No',
        'redirect_permalink' => '',
        'redirect_trashed' => '',
        'redirect_drafted' => '',
        'redirect_loggedin' => ''
    );
    if (!get_option('icarus_Main_Settings')) {
        add_option('icarus_Main_Settings', $icarus_Main_Settings);
    }
}

register_activation_hook(__FILE__, 'icarus_check_version');
function icarus_check_version() {
    	global $wp_version;
        if (!current_user_can('activate_plugins')) {
			echo '<p>' .
 			sprintf(
 			    __('You are not allowed to activate plugins!', 'oe-sb'),
 			    $php_version_required
 			)
 			. '</p>';
            die;
		}
		$php_version_required = '5.3';
		$wp_version_required = '2.7';
		
		if(version_compare(PHP_VERSION, $php_version_required, '<')) {
 			deactivate_plugins(basename(__FILE__));
 			echo '<p>' .
 			sprintf(
 			    __('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'),
 			    $php_version_required
 			)
 			. '</p>';
            die;
		}
        
		if(version_compare($wp_version, $wp_version_required, '<')) {
 			deactivate_plugins(basename(__FILE__));
			echo '<p>' .
			sprintf(
			__( 'This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb' ),
			$wp_version_required
			)
			. '</p>';
			die;
		}
    }

function icarus_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('admin_enqueue_scripts', 'icarus_load_admin_things');

add_action('admin_init', 'icarus_register_mysettings');



if (isset($_POST['icarus_301_redirects'])) {
	add_action('admin_init', 'icarus_save_redirects');
}

function icarus_add_cron_schedule( $schedules ) {
    $schedules['five'] = array(
        'interval' => 15,
        'display'  => __( 'Once Weekly' )
    );
    $schedules['weekly'] = array(
        'interval' => 604800,
        'display'  => __( 'Once Weekly' )
    );
    $schedules['monthly'] = array(
        'interval' => 2592000,
        'display'  => __( 'Once Monthly' )
    );
    return $schedules;
}

add_action('trash_post','my_trash_post_function',1,1);
function my_trash_post_function($post_id){
        $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
        if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_trashed']) && $icarus_Main_Settings['redirect_trashed'] == 'on')
            {
                $post_old_url = get_permalink($post_id);
                $short_old_url = str_ireplace(get_home_url(), '', $post_old_url);
                $new_url = get_home_url();
                $short_new_url ='/';
                $redirects = get_option('icarus_301_redirects');
                if(!$redirects)
                {
                    $redirects = array();
                }
                $cont = 0;
                foreach ($redirects as $storedrequest => $bundle[]) 
                {
                    $bundle_values = array_values($bundle); 
                    $myValues = $bundle_values[$cont];
                    $cont = $cont + 1;
                    $array_my_values = array_values($myValues); 
                    $destination = $array_my_values[0];
                    $short_destination = str_ireplace(get_home_url(), '', $destination);
                    $short_new_url = str_ireplace(get_home_url(), '', $new_url);
                    if(($short_old_url == $short_destination && $storedrequest == $short_new_url) || ($short_old_url == $storedrequest && $short_destination == $short_new_url))
                    {
                        //need to delete this, to avoid cycles and duplicates!
                        unset($redirects[$storedrequest]);
                        break;
                    }
                }
                $bundle = array();
                $bundle[] = $new_url;
                $bundle[] = 'All';//device
                $bundle[] = 'All';//login
                $bundle[] = '';//ip
                $bundle[] = 'ALL';//country
                $bundle[] = 'ALL';//language
                $bundle[] = 'All';//browser
                $bundle[] = '301';//redirect
                $bundle[] = '';//time
                $bundle[] = '';//end_time
                $bundle[] = '0';//logging
                $bundle[] = '1';//active
                $bundle[] = '0';//wildcard
                $redirects[$short_old_url] = $bundle;
                update_option('icarus_301_redirects', $redirects);
            }
        }
    
}

function icarus_get_draft_permalink( $post_id ) {

    require_once ABSPATH . '/wp-admin/includes/post.php';
    list( $permalink, $postname ) = get_sample_permalink( $post_id );

    return str_replace( '%postname%', $postname, $permalink );
}

add_action('draft_post','my_draft_post_function',1,1);
function my_draft_post_function($post_id){
        $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
        if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_drafted']) && $icarus_Main_Settings['redirect_drafted'] == 'on')
            {
                $post_old_url = icarus_get_draft_permalink($post_id);
                $short_old_url = str_ireplace(get_home_url(), '', $post_old_url);
                $new_url = get_home_url();
                $short_new_url ='/';
                $redirects = get_option('icarus_301_redirects');
                if(!$redirects)
                {
                    $redirects = array();
                }
                $cont = 0;
                foreach ($redirects as $storedrequest => $bundle[]) 
                {
                    $bundle_values = array_values($bundle); 
                    $myValues = $bundle_values[$cont];
                    $cont = $cont + 1;
                    $array_my_values = array_values($myValues); 
                    $destination = $array_my_values[0];
                    $short_destination = str_ireplace(get_home_url(), '', $destination);
                    $short_new_url = str_ireplace(get_home_url(), '', $new_url);
                    if(($short_old_url == $short_destination && $storedrequest == $short_new_url) || ($short_old_url == $storedrequest && $short_destination == $short_new_url))
                    {
                        //need to delete this, to avoid cycles and duplicates!
                        unset($redirects[$storedrequest]);
                        break;
                    }
                }
                $bundle = array();
                $bundle[] = $new_url;
                $bundle[] = 'All';//device
                $bundle[] = 'All';//login
                $bundle[] = '';//ip
                $bundle[] = 'ALL';//country
                $bundle[] = 'ALL';//language
                $bundle[] = 'All';//browser
                $bundle[] = '301';//redirect
                $bundle[] = '';//time
                $bundle[] = '';//end_time
                $bundle[] = '0';//logging
                $bundle[] = '1';//active
                $bundle[] = '0';//wildcard
                $redirects[$short_old_url] = $bundle;
                update_option('icarus_301_redirects', $redirects);
            }
        }
    
}

add_action('publish_post','my_publish_post_function',1,1);
function my_publish_post_function($post_id){
        $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
        if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
        {
                $post_old_url = icarus_get_draft_permalink($post_id);
                $short_old_url = str_ireplace(get_home_url(), '', $post_old_url);
                $new_url = get_home_url();
                $redirects = get_option('icarus_301_redirects');
                if(!$redirects)
                {
                    $redirects = array();
                }
                $cont = 0;
                $modified = 0;
                foreach ($redirects as $storedrequest => $bundle[]) 
                {
                    $bundle_values = array_values($bundle); 
                    $myValues = $bundle_values[$cont];
                    $cont = $cont + 1;
                    $array_my_values = array_values($myValues); 
                    $destination = $array_my_values[0];
                    if($short_old_url == $storedrequest && $destination == $new_url)
                    {
                        //delete draft entry
                        unset($redirects[$storedrequest]);
                        $modified = 1;
                        break;
                    }
                }
                if($modified == 1)
                {
                    update_option('icarus_301_redirects', $redirects);
                }
        }
    
}

add_filter('wp_insert_post_data', 'wpse_wp_insert_post_data', 10, 2);
function wpse_wp_insert_post_data($data, $post_attr)
{
    if( isset($post_attr['ID']))
    {
        $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
        if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_permalink']) && $icarus_Main_Settings['redirect_permalink'] == 'on')
            {
                $post = get_post($post_attr['ID']);
                if(isset($post->post_name))
                {            
                    $slug = $post->post_name;
                    if($slug != $data['post_name'])
                    {
                        $post_old_url = get_permalink($post_attr['ID']);
                        $short_old_url = str_ireplace(get_home_url(), '', $post_old_url);
                        $new_url = icarus_str_lreplace($slug, $data['post_name'], $post_old_url);
                        $redirects = get_option('icarus_301_redirects');
                        if(!$redirects)
                        {
                            $redirects = array();
                        }
                        $cont = 0;
                        foreach ($redirects as $storedrequest => $bundle[]) 
                        {
                            $bundle_values = array_values($bundle); 
                            $myValues = $bundle_values[$cont];
                            $cont = $cont + 1;
                            $array_my_values = array_values($myValues); 
                            $destination = $array_my_values[0];
                            $short_destination = str_ireplace(get_home_url(), '', $destination);
                            $short_new_url = str_ireplace(get_home_url(), '', $new_url);
                            if(($short_old_url == $short_destination && $storedrequest == $short_new_url) || ($short_old_url == $storedrequest && $short_destination == $short_new_url))
                            {
                                //need to delete this, to avoid cycles!
                                unset($redirects[$storedrequest]);
                                break;
                            }
                        }
                        $bundle = array();
                        $bundle[] = $new_url;
                        $bundle[] = 'All';//device
                        $bundle[] = 'All';//login
                        $bundle[] = '';//ip
                        $bundle[] = 'ALL';//country
                        $bundle[] = 'ALL';//language
                        $bundle[] = 'All';//browser
                        $bundle[] = '301';//redirect
                        $bundle[] = '';//time
                        $bundle[] = '';//end_time
                        $bundle[] = '0';//logging
                        $bundle[] = '1';//active
                        $bundle[] = '0';//wildcard
                        $redirects[$short_old_url] = $bundle;
                        update_option('icarus_301_redirects', $redirects);
                    }
                }
            }
        }
    }
    return $data;
}

function icarus_str_lreplace($search, $replace, $subject)
{
    $pos = strrpos($subject, $search);

    if($pos !== false)
    {
        $subject = substr_replace($subject, $replace, $pos, strlen($search));
    }

    return $subject;
}

function icarus_function_to_run() {
    if(file_exists(WP_CONTENT_DIR . '/icarus_info.log'))
    {
        unlink(WP_CONTENT_DIR . '/icarus_info.log');
    }
    if(file_exists(WP_CONTENT_DIR . '/icarus_debug.log'))
    {
        unlink(WP_CONTENT_DIR . '/icarus_debug.log');
    }
}


function icarus_register_mysettings()
{
    register_setting('icarus_option_group', 'icarus_Main_Settings');
    register_setting('icarus_option_group2', 'icarus_301_redirects');
}
add_filter('cron_schedules', 'icarus_add_cron_schedule' );
icarus_cron_schedule();
function icarus_cron_schedule()
{
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
    {
        add_action('icarusaction', 'icarus_function_to_run' );
    
        if(isset($icarus_Main_Settings['redirect_clear_log']) && $icarus_Main_Settings['redirect_clear_log'] !== 'No')
        {
            if (!wp_next_scheduled( 'icarusaction')) 
            {
                wp_schedule_event(time(), $icarus_Main_Settings['redirect_clear_log'], 'icarusaction' );
                add_option('icarus_schedule_time', $icarus_Main_Settings['redirect_clear_log']);
            }
            else
            {
                if (!get_option('icarus_schedule_time')) {
                    wp_clear_scheduled_hook( 'icarusaction' );
                    wp_schedule_event(time(), $icarus_Main_Settings['redirect_clear_log'], 'icarusaction' );
                    add_option('icarus_schedule_time', $icarus_Main_Settings['redirect_clear_log']);
                }
                else
                {
                    $the_time = get_option('icarus_schedule_time');
                    if($the_time != $icarus_Main_Settings['redirect_clear_log'])
                    {
                        wp_clear_scheduled_hook( 'icarusaction' );
                        delete_option('icarus_schedule_time');
                        wp_schedule_event(time(), $icarus_Main_Settings['redirect_clear_log'], 'icarusaction' );
                        add_option('icarus_schedule_time', $icarus_Main_Settings['redirect_clear_log']);
                    }
                }
            }
        }
        else
        {
            if (!wp_next_scheduled( 'icarusaction' )) 
            {
                delete_option('icarus_schedule_time');
            }
            else
            {
                wp_clear_scheduled_hook( 'icarusaction' );
                delete_option('icarus_schedule_time');
            }
        }
    }        
}

function icarus_get_plugin_url() {
    	return plugins_url('', __FILE__);
}

function icarus_get_file_url($url) {
	return icarus_get_plugin_url() . '/' . $url;
}	
function icarus_get_address() {
	return icarus_get_protocol().'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
}
function icarus_get_protocol() {
	$protocol = 'http';
	if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
    	$protocol .= "s";
	}
	return $protocol;
}

function icarus_get_redirect_url($url){
    $redirect_url = null; 

    $url_parts = @parse_url($url);
    if (!$url_parts) return false;
    if (!isset($url_parts['host'])) return false;
    if (!isset($url_parts['path'])) $url_parts['path'] = '/';

    $sock = fsockopen($url_parts['host'], (isset($url_parts['port']) ? (int)$url_parts['port'] : 80), $errno, $errstr, 30);
    if (!$sock) return false;

    $request = "HEAD " . $url_parts['path'] . (isset($url_parts['query']) ? '?'.$url_parts['query'] : '') . " HTTP/1.1".PHP_EOL; 
    $request .= 'Host: ' . $url_parts['host'] . PHP_EOL; 
    $request .= "Connection: Close".PHP_EOL.PHP_EOL; 
    fwrite($sock, $request);
    $response = '';
    while(!feof($sock)) $response .= fread($sock, 8192);
    fclose($sock);

    if (preg_match('/^Location: (.+?)$/m', $response, $matches)){
        if ( substr($matches[1], 0, 1) == "/" )
            return $url_parts['scheme'] . "://" . $url_parts['host'] . trim($matches[1]);
        else
            return trim($matches[1]);

    } else {
        return false;
    }
}

function icarus_get_all_redirects($url){
    $redirects = array();
    while ($newurl = icarus_get_redirect_url($url)){
        if (in_array($newurl, $redirects)){
            break;
        }
        $redirects[] = $newurl;
        $url = $newurl;
    }
    return $redirects;
}

function icarus_wp_redirect($url, $type = 301)
{
    if(!headers_sent())
    {
        wp_redirect($url, $type);
    }
    else
    {
        echo '<meta http-equiv="refresh" content="0;url='.$url.'"/>';
    }
    exit();
}

function icarus_get_final_url($url){
    if (strpos($url, 'localhost') !== false)
    {
        return $url;
    }
    $redirects = icarus_get_all_redirects($url);
    if (count($redirects)>0){
        return array_pop($redirects);
    } else {
        return $url;
    }
}
if(!is_admin()) {
    remove_filter('template_redirect', 'redirect_canonical');
    add_action('template_redirect', 'icarus_redirect_main');
}

function icarus_comment_redirect( $url, $comment ) {
	$cc = get_comments( array( 'author_email' => $comment->comment_author_email, 'count' => true ) );
	if ( 1 == $cc ) {
		$icarus_Main_Settings = get_option('icarus_Main_Settings', false);
        $url = $icarus_Main_Settings['redirect_comment_link'];
        icarus_wp_redirect($url, 301);
	} 
	return $url;
}

function icarus_isSecure() {
  return
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || $_SERVER['SERVER_PORT'] == 443;
}

function icarus_redirect_adblock($icarus_Main_Settings) 
{
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    $redirect_link = $icarus_Main_Settings['redirect_adblock_link'];
    echo '<script type="text/javascript">var adblock = true;</script><script type="text/javascript" src="' . plugin_dir_url( __FILE__ ) . 'res/adframe.js"></script><script type="text/javascript">if(adblock) {window.location = "'.$icarus_Main_Settings['redirect_adblock_link'].'";}</script>';
    //method2 -> slower
    //echo "<script>var adBlockEnabled = false; var testAd = document.createElement('div'); testAd.innerHTML = '&nbsp;'; testAd.className = 'adsbox';document.body.appendChild(testAd);window.setTimeout(function() {if (testAd.offsetHeight === 0) {adBlockEnabled = true;}testAd.remove();if(adBlockEnabled == true){window.location = '".$icarus_Main_Settings['redirect_adblock_link']."';}}, 100);</script>";
}

function icarus_redirect_main()
{
    global $post;
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    if(isset($icarus_Main_Settings['icarus_enabled']) && $icarus_Main_Settings['icarus_enabled'] === 'on')
    {
        $enable_debug_log = 'off';
        if(isset($icarus_Main_Settings['redirect_enable_log']) && $icarus_Main_Settings['redirect_enable_log'] === 'on')
        {
            $enable_debug_log = 'on';
        }
        if(isset($icarus_Main_Settings['redirect_loggedin']) && $icarus_Main_Settings['redirect_loggedin'] === 'on')
        {
            if (!is_user_logged_in()) {
                icarus_debug_log_to_file("Redirect not logged in user", $enable_debug_log);
                icarus_wp_redirect(wp_login_url(), 301);
            }
        }
        if(isset($icarus_Main_Settings['redirect_attachment']) && $icarus_Main_Settings['redirect_attachment'] === 'on')
        {
            if ( is_attachment() && isset($post->post_parent) && is_numeric($post->post_parent) && ($post->post_parent != 0) ) {
                icarus_debug_log_to_file("Redirect is_attachment page 301", $enable_debug_log);
                icarus_wp_redirect(get_permalink($post->post_parent), 301);
            } elseif ( is_attachment() && isset($post->post_parent) && is_numeric($post->post_parent) && ($post->post_parent < 1) ) {
                icarus_debug_log_to_file("Redirect is_attachment page 302", $enable_debug_log);
                icarus_wp_redirect(get_bloginfo('wpurl'), 302);     
            }
        }
        if(isset($icarus_Main_Settings['redirect_http']) && $icarus_Main_Settings['redirect_http'] !== 'No')
        {
            if ($icarus_Main_Settings['redirect_http'] === 'Http') 
            {
                if(icarus_isSecure())
                {
                    if ( 0 === strpos( $_SERVER['REQUEST_URI'], 'https' ) ) 
                    {
                        icarus_debug_log_to_file("Redirect from HTTPS to HTTP", $enable_debug_log);
                        icarus_wp_redirect( preg_replace( '|^https://|', 'http://', $_SERVER['REQUEST_URI'] ), 301 );
                    }
                    elseif(0 !== strpos( $_SERVER['REQUEST_URI'], 'http' ))
                    {
                        icarus_debug_log_to_file("Redirect from HTTPS to HTTP (no http in header)", $enable_debug_log);
                        icarus_wp_redirect( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
                    }
                }
            }
            elseif($icarus_Main_Settings['redirect_http'] === 'Https')
            {
                if(!icarus_isSecure())
                {
                    if ( 0 === strpos( $_SERVER['REQUEST_URI'], 'http' ) && 0 !== strpos( $_SERVER['REQUEST_URI'], 'https' )) 
                    {
                        icarus_debug_log_to_file("Redirect from HTTP to HTTPS", $enable_debug_log);
                        icarus_wp_redirect( preg_replace( '|^http://|', 'https://', $_SERVER['REQUEST_URI'] ), 301 );    
                    }
                    elseif(0 !== strpos( $_SERVER['REQUEST_URI'], 'https' ) )
                    {
                        icarus_debug_log_to_file("Redirect from HTTPS to HTTP (no https in header)", $enable_debug_log);
                        icarus_wp_redirect( 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
                    }
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_www']) && $icarus_Main_Settings['redirect_www'] !== 'No')
        {
            if ($icarus_Main_Settings['redirect_www'] === 'www') 
            {
                if(isset($_SERVER['HTTP_HOST']) && substr($_SERVER['HTTP_HOST'], 0, 4) !== 'www.')
                {
                    $pageURL = (icarus_isSecure()) ? "https://" : "http://";
                    if ($_SERVER["SERVER_PORT"] != "80")
                    {
                        $pageURL .= "www." . $_SERVER["HTTP_HOST"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
                    } 
                    else 
                    {
                        $pageURL .= "www." . $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
                    }
                    icarus_debug_log_to_file("Redirect from non-www to www " . $pageURL, $enable_debug_log);
                    icarus_wp_redirect( $pageURL, 301 );
                }
            }
            elseif($icarus_Main_Settings['redirect_www'] === 'no-www')
            {
                if(isset($_SERVER['HTTP_HOST']) && substr($_SERVER['HTTP_HOST'], 0, 4) === 'www.')
                {
                    $pageURL = (icarus_isSecure()) ? "https://" : "http://";
                    if ($_SERVER["SERVER_PORT"] != "80")
                    {
                        $pageURL .= substr($_SERVER['HTTP_HOST'], 4).":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
                    } 
                    else 
                    {
                        $pageURL .= substr($_SERVER['HTTP_HOST'], 4).$_SERVER["REQUEST_URI"];
                    }
                    icarus_debug_log_to_file("Redirect from www to non-www " . $pageURL, $enable_debug_log);
                    icarus_wp_redirect( $pageURL, 301 );
                }
            }
        }
        $actual_link = 'http' . ((icarus_isSecure()) ? 's' : '') . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $short_url = str_ireplace(get_home_url(),'',$actual_link);
        if(isset($icarus_Main_Settings['redirect_random']) && $icarus_Main_Settings['redirect_random'] === 'on')
        {
            if($icarus_Main_Settings['redirect_random_url'] !== '')
            {
                $link = $icarus_Main_Settings['redirect_random_url'];
                if(rtrim($short_url,'/') === rtrim($link,'/'))
                {
                    $do_redirect = '';
                    $posts = get_posts('post_type=post&orderby=rand&numberposts=1');
                    foreach($posts as $post) {
                        $do_redirect = get_permalink($post);
                    }
                    if(!headers_sent())
                    {
                        header("HTTP/1.1 301 Moved Permanently");
                        header("Status: 301 Moved Permanently");
                        if($do_redirect !== '')
                        {
                            icarus_debug_log_to_file("Redirecting to rangom URL: " . $do_redirect, $enable_debug_log);
                            header("Location: " . $do_redirect);
                        }
                        header("Connection: close");
                        exit(0);
                    }
                    else
                    {
                        if($do_redirect !== '')
                        {
                            icarus_wp_redirect($do_redirect, 301);
                        }
                    }
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_time_based']) && $icarus_Main_Settings['redirect_time_based'] === 'on')
        {
            $start_time = '';
            $end_time = '';
            $start_date = '';
            $end_date = '';
            if(isset($icarus_Main_Settings['start_time']))
            {
                $start_time = $icarus_Main_Settings['start_time'];
            }
            if(isset($icarus_Main_Settings['end_time']))
            {
                $end_time = $icarus_Main_Settings['end_time'];
            }
            if(isset($icarus_Main_Settings['start_date']))
            {
                $start_date = $icarus_Main_Settings['start_date'];
            }
            if(isset($icarus_Main_Settings['end_date']))
            {
                $end_date = $icarus_Main_Settings['end_date'];
            }
            if($start_date !== '' && $end_date !== '')
            {
                $date1 = new DateTime();
                $date2 = DateTime::createFromFormat('m/d/Y', $start_date);
                $date3 = DateTime::createFromFormat('m/d/Y', $end_date);
                if ($date1 < $date2 || $date1 > $date3)
                {
                    icarus_debug_log_to_file("Date was outside the given date range", $enable_debug_log);
                    return;
                }
                elseif ($date1 == $date2)
                {
                    if($start_time !== '')
                    {
                        $date2 = DateTime::createFromFormat('H:ia', $start_time);
                        if ($date1 < $date2)
                        {
                            icarus_debug_log_to_file("Date is today, but before starting hour.", $enable_debug_log);
                            return;
                        }
                    }
                    if ($date1 == $date3)
                    {
                        if($end_time !== '')
                        {
                            $date3 = DateTime::createFromFormat('H:ia', $end_time);
                            if ($date1 > $date3)
                            {
                                icarus_debug_log_to_file("Date is today, but after ending hour.", $enable_debug_log);
                                return;
                            }
                        }
                    }
                }
                elseif ($date1 == $date3)
                {
                    if($end_time !== '')
                    {
                        $date3 = DateTime::createFromFormat('H:ia', $end_time);
                        if ($date1 > $date3)
                        {
                            icarus_debug_log_to_file("Date is today (final), but after ending hour.", $enable_debug_log);
                            return;
                        }
                    }
                }
            }
            else
            {
                if($start_time !== '' && $end_time !== '')
                {
                    $date1 = new DateTime();
                    $date2 = DateTime::createFromFormat('H:ia', $start_time);
                    $date3 = DateTime::createFromFormat('H:ia', $end_time);
                    if ($date1 < $date2 || $date1 > $date3)
                    {
                        icarus_debug_log_to_file("Only hours are set, and time is outside set range", $enable_debug_log);
                        return;
                    }
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_maintenance']) && $icarus_Main_Settings['redirect_maintenance'] === 'on')
        {
            if(!is_user_logged_in() || (is_user_logged_in() && !current_user_can('administrator')))
            {
                if(!headers_sent())
                {
                    header('HTTP/1.0 503 Service Unavailable');
                    include_once(dirname(__FILE__) . "/res/icarus-maintenance-template.php");
                    exit();
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_enable_referrer']) && $icarus_Main_Settings['redirect_enable_referrer'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_referrer_link']))
            {
                $matching = false;
                $ref_link = $icarus_Main_Settings['redirect_referrer_link'];
                $pieces = explode(",", $ref_link);
                if(isset($_SERVER['HTTP_REFERER'])) 
                {
                    $current_ref = $_SERVER['HTTP_REFERER'];
                }
                else
                {
                    $current_ref = "";
                }
                foreach($pieces as $piece) {
                    $piece = trim($piece);
                    if(strcasecmp($piece, $current_ref) == 0)
                    {
                        $matching = true;
                    }
                }
                if($matching == false)
                {
                    icarus_debug_log_to_file("Referrer not good: " . $ref_link . " and " . $current_ref, $enable_debug_log);
                    return;
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_enable_username']) && $icarus_Main_Settings['redirect_enable_username'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_username']))
            {
                $username = $icarus_Main_Settings['redirect_username'];
                $current_user = wp_get_current_user();
                $pieces = explode(",", $username);
                $matching = false;
                foreach($pieces as $piece) {
                    $piece = trim($piece);
                    if(strcasecmp($piece, $current_user->user_login) == 0)
                    {
                        $matching = true;
                    }
                }
                if($matching == false)
                {
                    icarus_debug_log_to_file("Username not good: " . $username . " and " . $current_user->user_login, $enable_debug_log);
                    return;
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_adblock']) && $icarus_Main_Settings['redirect_adblock'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_adblock_link']))
            {
                add_action('wp_head', 'icarus_redirect_adblock');
            }
        }
        if(isset($icarus_Main_Settings['redirect_enable_os']) && $icarus_Main_Settings['redirect_enable_os'] === 'on')
        {
            if(isset($icarus_Main_Settings['redirect_os']))
            {
                $os = $icarus_Main_Settings['redirect_os'];
                $userOs = icarus_getOS();
                if($os === "All Windows")
                {
                    if (stripos($userOs, 'Windows') === false) 
                    {
                        icarus_debug_log_to_file("OS not good: " . $userOs . " and " . $os, $enable_debug_log);
                        return;
                    }
                }
                elseif($os === "All Apple")
                {
                    if($userOs !== "iOs" && $userOs !== "iPhone" && $userOs !== "iPod" && $userOs !== "iPad")
                    {
                        icarus_debug_log_to_file("OS not good: " . $userOs . " and " . $os, $enable_debug_log);
                        return;
                    }
                }
                elseif($os === "All Mac")
                {
                    if($userOs !== "Mac OS X" && $userOs !== "Mac OS 9")
                    {
                        icarus_debug_log_to_file("OS not good: " . $userOs . " and " . $os, $enable_debug_log);
                        return;
                    }
                }
                elseif($os === "All Linux")
                {
                    if($userOs !== "Linux" && $userOs !== "Ubuntu")
                    {
                        icarus_debug_log_to_file("OS not good: " . $userOs . " and " . $os, $enable_debug_log);
                        return;
                    }
                }
                else
                {
                    if($os !== $userOs)
                    {
                        icarus_debug_log_to_file("OS not good: " . $userOs . " and " . $os, $enable_debug_log);
                        return;
                    }
                }
            }
        }
        $redirects = get_option('icarus_301_redirects');
        if (!empty($redirects)) 
        {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            $mobile = false;
            $tablet = false;
            $bot = false;
            preg_match( '/Altavista|ia_archiver|facebookexternalhit|googlebot|adsbot|Yahoo!|Baiduspider|Yandex|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/i', $user_agent, $goodbot);
            preg_match( '#bot|SiteLockSpider|crawler|archiver|transcoder|spider|uptime|validator|fetcher|MJ12bot|Ezooms|AhrefsBot|FHscan|Acunetix|Zyborg|ZmEu|Zeus|Xenu|Xaldon|WWW-Collector-E|WWWOFFLE|WISENutbot|Widow|Whacker|WebZIP|WebWhacker|WebStripper|Webster|Website\ Quester|Website\ eXtractor|WebSauger|WebReaper|WebmasterWorldForumBot|WebLeacher|Web.Image.Collector|WebGo\ IS|WebFetch|WebEnhancer|WebEMailExtrac|WebCopier|Webclipping.com|WebBandit|WebAuto|Web\ Sucker|Web\ Image\ Collector|VoidEYE|VCI|Vacuum|URLy.Warning|TurnitinBot|turingos|True_Robot|Titan|TightTwatBot|TheNomad|The.Intraformant|TurnitinBot/1.5|Telesoft|Teleport|tAkeOut|Szukacz/1.4|suzuran|Surfbot|SuperHTTP|SuperBot|Sucker|Stripper|Sqworm|spanner|SpankBot|SpaceBison|Snoopy|Snapbot|Snake|SmartDownload|SlySearch|SiteSnagger|Siphon|RMA|RepoMonkey|ReGet|Recorder|Reaper|RealDownload|QueryN.Metasearch|Pump|psbot|ProWebWalker|ProPowerBot/2.14|Pockey|PHP\ version\ tracker|pcBrowser|pavuk|Papa\ Foto|PageGrabber|OutfoxBot|Openfind|Offline\ Navigator|Offline\ Explorer|Octopus|NPbot|Ninja|NimbleCrawler|niki-bot|NICErsPRO|NG|NextGenSearchBot|NetZIP|Net\ Vampire|NetSpider|NetMechanic|Netcraft|NetAnts|NearSite|Navroad|NAMEPROTECT|Mozilla.*NEWT|Mozilla/3.Mozilla/2.01|moget|Mister\ PiX|Missigua\ Locator|Mirror|MIIxpc|MIDown\ tool|Microsoft\ URL\ Control|Microsoft.URL|Memo|Mata.Hari|Mass\ Downloader|MarkWatch|Mag-Net|Magnet|LWP::Simple|lwp-trivial|LinkWalker|LNSpiderguy|LinkScan/8.1a.Unix|LinkextractorPro|likse|libWeb/clsHTTP|lftp|LexiBot|larbin|Keyword.Density|Kenjin.Spider|Jyxobot|JustView|JOC|JetCar|JennyBot|Jakarta|Iria|Internet\ Ninja|InterGET|Intelliseek|InfoTekies|InfoNaviRobot|Indy\ Library|Image\ Sucker|Image\ Stripper|IlseBot|humanlinks|HTTrack|HMView|hloader|Harvest|Grafula|GrabNet|gotit|Go-Ahead-Got-It|FrontPage|flunky|Foobot|EyeNetIE|Extractor|Express\ WebPictures|Exabot|EroCrawler|EmailWolf|EmailSiphon|EmailCollector|EirGrabber|ebingbong|EasyDL|eCatch|Drip|dragonfly|Download\ Wonder|Download\ Devil|Download\ Demon|DittoSpyder|DIIbot|DISCo|AIBOT|Aboundex|Custo|Crescent|cosmos|CopyRightCheck|Copier|Collector|ChinaClaw|CherryPicker|CheeseBot|Cegbfeieh|BunnySlippers|Bullseye|BuiltBotTough|Buddy|BotALot|BlowFish|BlackWidow|Black.Hole|Bigfoot|BatchFTP|Bandit|BackWeb|BackDoorBot|80legs|360Spider|Java|Cogentbot|Alexibot|asterias|attach|eStyle|WebCrawler|Dumbot|CrocCrawler|ASPSeek|AcoiRobot|DuckDuckBot|BLEXBot|Ips Agent|bot|crawl|slurp|spider|outbrain|008|192.comAgent|2ip\.ru|404checker|^bluefish |^FDM |^git|^Goose|^HTTPClient|^Java|^Jetty|^Mget|^Microsoft URL Control|^NG\/[0-9\.]|^NING|^PHP\/[0-9]|^RMA|^Ruby|Ruby\/[0-9]|^scrutiny|^VSE\/[0-9]|^WordPress\.com|^XRL\/[0-9]|a3logics\.in|A6-Indexer|a\.pr-cy\.ru|Aboundex|aboutthedomain|Accoona|acoon|acrylicapps\.com\/pulp|adbeat|AddThis|ADmantX|adressendeutschland|Advanced Email Extractor v|agentslug|AHC|aihit|aiohttp|Airmail|akula|alertra|alexa site audit|Alibaba\.Security\.Heimdall|alyze\.info|amagit|AndroidDownloadManager|Anemone|Ant\.com|Anturis Agent|AnyEvent-HTTP|Apache-HttpClient|AportWorm\/[0-9]|AppEngine-Google|Arachmo|arachnode|Arachnophilia|archive-com|aria2|asafaweb.com|AskQuickly|Astute|asynchttp|autocite|Autonomy|B-l-i-t-z-B-O-T|Backlink-Ceck\.de|Bad-Neighborhood|baidu\.com|baypup\/[0-9]|baypup\/colbert|BazQux|BCKLINKS|BDFetch|BegunAdvertising|bibnum\.bnf|BigBozz|biglotron|BingLocalSearch|BingPreview|binlar|biz_Directory|Blackboard Safeassign|Bloglovin|BlogPulseLive|BlogSearch|Blogtrottr|boitho\.com-dc|BPImageWalker|Braintree-Webhooks|Branch Metrics API|Branch-Passthrough|Browsershots|BUbiNG|Butterfly|BuzzSumo|CakePHP|CapsuleChecker|CaretNail|cb crawl|CC Metadata Scaper|Cerberian Drtrs|CERT\.at-Statistics-Survey|cg-eye|changedetection|Charlotte|CheckHost|chkme\.com|CirrusExplorer|CISPA Vulnerability Notification|CJNetworkQuality|clips\.ua\.ac\.be|Cloud mapping experiment|CloudFlare-AlwaysOnline|Cloudinary\/[0-9]|cmcm\.com|coccoc|CommaFeed|Commons-HttpClient|Comodo SSL Checker|contactbigdatafr|convera|copyright sheriff|cosmos\/[0-9]|Covario-IDS|CrawlForMe\/[0-9]|cron-job\.org|Crowsnest|curb|Curious George|curl|cuwhois\/[0-9]|CyberPatrol|cybo\.com|DareBoost|DataparkSearch|dataprovider|Daum(oa)?[ \/][0-9]|DeuSu|developers\.google\.com\/\+\/web\/snippet|Digg|Dispatch|dlvr|DNS-Tools Header-Analyzer|DNSPod-reporting|docoloc|DomainAppender|dotSemantic|downforeveryoneorjustme|downnotifier\.com|DowntimeDetector|Dragonfly File Reader|drupact|Drupal (\+http:\/\/drupal\.org\/)|dubaiindex|EARTHCOM|Easy-Thumb|ec2linkfinder|eCairn-Grabber|ECCP|ElectricMonk|elefent|EMail Exractor|EmailWolf|Embed PHP Library|Embedly|europarchive\.org|evc-batch\/[0-9]|EventMachine HttpClient|Evidon|Evrinid|ExactSearch|ExaleadCloudview|Excel|Exploratodo|ezooms|facebookexternalhit|facebookplatform|fairshare|Faraday v|Faveeo|Favicon downloader|FavOrg|Feed Wrangler|Feedbin|FeedBooster|FeedBucket|FeedBurner|FeedChecker|Feedly|Feedspot|feeltiptop|Fetch API|Fetch\/[0-9]|Fever\/[0-9]|findlink|findthatfile|Flamingo_SearchEngine|FlipboardBrowserProxy|FlipboardProxy|FlipboardRSS|fluffy|flynxapp|forensiq|FoundSeoTool\/[0-9]|free thumbnails|FreeWebMonitoring SiteChecker|Funnelback|g00g1e\.net|GAChecker|geek-tools|Genderanalyzer|Genieo|GentleSource|GetLinkInfo|getprismatic\.com|GetURLInfo\/[0-9]|GigablastOpenSource|Go [\d\.]* package http|Go-http-client|GomezAgent|gooblog|Goodzer\/[0-9]|Google favicon|Google Keyword Suggestion|Google Keyword Tool|Google Page Speed Insights|Google PP Default|Google Search Console|Google Web Preview|Google-Adwords|Google-Apps-Script|Google-Calendar-Importer|Google-HTTP-Java-Client|Google-Publisher-Plugin|Google-SearchByImage|Google-Site-Verification|Google-Structured-Data-Testing-Tool|google_partner_monitoring|GoogleDocs|GoogleHC|GoogleProducer|GoScraper|GoSpotCheck|GoSquared-Status-Checker|gosquared-thumbnailer|GotSiteMonitor|Grammarly|grouphigh|grub-client|GTmetrix|gvfs|HAA(A)?RTLAND http client|Hatena|hawkReader|HEADMasterSEO|HeartRails_Capture|heritrix|hledejLevne\.cz\/[0-9]|Holmes|HootSuite Image proxy|Hootsuite-WebFeed\/[0-9]|HostTracker|ht:\/\/check|htdig|HTMLParser|HTTP-Header-Abfrage|http-kit|HTTP-Tiny|HTTP_Compression_Test|http_request2|http_requester|HttpComponents|httphr|HTTPMon|httpscheck|httpssites_power|httpunit|HttpUrlConnection|httrack|hosterstats|huaweisymantec|HubPages.*crawlingpolicy|HubSpot Connect|HubSpot Marketing Grader|HyperZbozi.cz Feeder|ichiro|IdeelaborPlagiaat|IDG Twitter Links Resolver|IDwhois\/[0-9]|Iframely|igdeSpyder|IlTrovatore|ImageEngine|Imagga|InAGist|inbound\.li parser|InDesign|infegy|infohelfer|InfoWizards Reciprocal Link System PRO|inpwrd\.com|Integrity|integromedb|internet_archive|InternetSeer|internetVista monitor|IODC|IOI|ips-agent|iqdb|Irokez|isitup\.org|iskanie|iZSearch|janforman|Jigsaw|Jobboerse|jobo|Jobrapido|KeepRight OpenStreetMap Checker|KickFire|KimonoLabs|knows\.is|kouio|KrOWLer|kulturarw3|KumKie|L\.webis|Larbin|LayeredExtractor|LibVLC|libwww|Liferea|link checker|Link Valet|link_thumbnailer|linkCheck|linkdex|LinkExaminer|linkfluence|linkpeek|LinkTiger|LinkWalker|Lipperhey|livedoor ScreenShot|LoadImpactPageAnalyzer|LoadImpactRload|LongURL API|looksystems\.net|ltx71|lwp-trivial|lycos|LYT\.SR|mabontland|MagpieRSS|Mail.Ru|MailChimp\.com|Mandrill|marketinggrader|Mediapartners-Google|MegaIndex\.ru|Melvil Rawi|MergeFlow-PageReader|MetaInspector|Metaspinner|MetaURI|Microsearch|Microsoft Office |Microsoft Windows Network Diagnostics|Mindjet|Miniflux|Mnogosearch|mogimogi|Mojolicious (Perl)|monitis|Monitority\/[0-9]|montastic|MonTools|Moreover|Morning Paper|mowser|Mrcgiguy|mShots|MVAClient|nagios|Najdi\.si|NETCRAFT|NetLyzer FastProbe|netresearch|NetShelter ContentScan|NetTrack|Netvibes|Neustar WPM|NeutrinoAPI|NewsBlur .*Finder|NewsGator|newsme|newspaper|NG-Search|nineconnections\.com|NLNZ_IAHarvester|Nmap Scripting Engine|node-superagent|node\.io|nominet\.org\.uk|Norton-Safeweb|Notifixious|notifyninja|nuhk|nutch|Nuzzel|nWormFeedFinder|Nymesis|Ocelli\/[0-9]|oegp|okhttp|Omea Reader|omgili|Online Domain Tools|OpenCalaisSemanticProxy|Openstat|OpenVAS|Optimizer|Orbiter|OrgProbe\/[0-9]|ow\.ly|ownCloud News|Page Analyzer|Page Valet|page2rss|page_verifier|PagePeeker|Pagespeed\/[0-9]|Panopta|panscient|parsijoo|PayPal IPN|Pcore-HTTP|Pearltrees|peerindex|Peew|PhantomJS|Photon|phpcrawl|phpservermon|Pi-Monster|Pingdom\.com|Pingoscope|PingSpot|Pinterest|Pizilla|Ploetz \+ Zeller|Plukkie|PocketParser|Pompos|Porkbun|Port Monitor|postano|PostPost|postrank|PowerPoint|Priceonomics Analysis Engine|Prlog|probethenet|Project 25499|Promotion_Tools_www.searchenginepromotionhelp.com|prospectb2b|Protopage|proximic|PTST |PTST\/[0-9]+|Pulsepoint XT3 web scraper|Python-httplib2|python-requests|Python-urllib|Qirina Hurdler|Qseero|Qualidator.com SiteAnalyzer|Quora Link Preview|Qwantify|Radian6|RankSonicSiteAuditor|Readability|RealPlayer%20Downloader|RebelMouse|redback|Redirect Checker Tool|ReederForMac|request\.js|ResponseCodeTest\/[0-9]|RestSharp|RetrevoPageAnalyzer|Riddler|Rival IQ|Robosourcer|Robozilla\/[0-9]|ROI Hunter|SalesIntelligent|SauceNAO|SBIder|Scoop|scooter|ScoutJet|ScoutURLMonitor|Scrapy|Scrubby|SearchSight|semanticdiscovery|semanticjuice|SEO Browser|Seo Servis|seo-nastroj.cz|Seobility|SEOCentro|SeoCheck|SeopultContentAnalyzer|SEOstats|Server Density Service Monitoring|servernfo\.com|Seznam screenshot-generator|Shelob|Shoppimon Analyzer|ShoppimonAgent\/[0-9]|ShopWiki|ShortLinkTranslate|shrinktheweb|SilverReader|SimplePie|SimplyFast|Site-Shot|Site24x7|SiteBar|SiteCondor|siteexplorer\.info|SiteGuardian|Siteimprove\.com|Sitemap(s)? Generator|Siteshooter B0t|SiteTruth|sitexy\.com|SkypeUriPreview|slider\.com|slurp|SMRF URL Expander|SMUrlExpander|Snappy|SniffRSS|sniptracker|Snoopy|sogou|SortSite|spaziodati|Specificfeeds|speedy|SPEng|Spinn3r|spray-can|Sprinklr |spyonweb|Sqworm|SSL Labs|Rambler|Statastico|StatusCake|Stratagems Kumo|Stroke.cz|StudioFACA|suchen|summify|Super Monitoring|Surphace Scout|SwiteScraper|Symfony2 BrowserKit|SynHttpClient-Built|Sysomos|T0PHackTeam|Tarantula|teoma|terrainformatica\.com|The Expert HTML Source Viewer|theinternetrules|theoldreader\.com|Thumbshots|ThumbSniper|TinEye|Tiny Tiny RSS|topster|touche.com|Traackr.com|truwoGPS|tweetedtimes\.com|Tweetminster|Twikle|Twingly|Typhoeus|ubermetrics-technologies|uclassify|UdmSearch|UnwindFetchor|updated|Upflow|URLChecker|URLitor.com|urlresolver|Urlstat|UrlTrends Ranking Updater|Vagabondo|via ggpht\.com GoogleImageProxy|visionutils|vkShare|voltron|Vortex\/[0-9]|voyager|VSAgent\/[0-9]|VSB-TUO\/[0-9]|VYU2|w3af\.org|W3C-checklink|W3C-mobileOK|W3C_I18n-Checker|W3C_Unicorn|wangling|Wappalyzer|WatchMouse|WbSrch|web-capture\.net|Web-Monitoring|Web-sniffer|Webauskunft|WebCapture|webcollage|WebCookies|WebCorp|WebDoc|WebFetch|WebImages|WebIndex|webkit2png|webmastercoffee|webmon |webscreenie|Webshot|Website Analyzer|websitepulse[+ ]checker|Websnapr|Websquash\.com|Webthumb\/[0-9]|WebThumbnail|WeCrawlForThePeace|WeLikeLinks|WEPA|WeSEE|wf84|wget|WhatsApp|WhatsMyIP|WhatWeb|Whibse|Whynder Magnet|Windows-RSS-Platform|WinHttpRequest|wkhtmlto|wmtips|Woko|WomlpeFactory|Word|WordPress|wotbox|WP Engine Install Performance API|WPScan|wscheck|WWW-Mechanize|www\.monitor\.us|XaxisSemanticsClassifier|Xenu Link Sleuth|XING-contenttabreceiver\/[0-9]|XmlSitemapGenerator|xpymep([0-9]?)\.exe|Y!J-(ASR|BSC)|Yaanb|yacy|Yahoo Ad monitoring|Yahoo Link Preview|YahooCacheSystem|YahooSeeker|YahooYSMcm|YandeG|yandex|yanga|yeti|Yo-yo|Yoleo Consumer|yoogliFetchAgent|YottaaMonitor|yourls\.org|Zao|Zemanta Aggregator|Zend\\\\Http\\\\Client|Zend_Http_Client|zgrab|ZnajdzFoto|ZyBorg#i', $user_agent, $badbot);
            if($goodbot || $badbot)
            {
                $bot = true;
            }
            preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $user_agent, $matches);
            preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($user_agent,0,4), $matches2);
            if($matches || $matches2)
            {
                $mobile = true;
            }
            preg_match('/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle|NRD90M|SGP771|SHIELD|SM-T550|KFTHWI|LG-V410|nexus/i', $user_agent, $matches3);
            if($matches3)
            {
                $tablet = true;
            }
            $bd = new icarusBrowserDetection();
            $browser =  $bd->icarus_detect()->icarus_getBrowser();
            if(stripos($browser, 'explorer') !== false) {
	    		$browser = 'IE';
	    	} 
	    	elseif(stripos($browser, 'chrome') !== false) {
                if( stripos($user_agent,'edge/') !== false ) 
                {
                    $aresult = explode('/', stristr($user_agent, 'edge'));
                    if (isset($aresult[1])) 
                    {
                        $browser = 'Edge';
                    }
                    else
                    {
                        $browser = 'Chrome';
                    }
                }
                else
                {
                    $browser = 'Chrome';
                }
	    	}
            elseif(stripos($browser, 'edge') !== false) {
				$browser = 'Edge';
	    	} 
	    	elseif(stripos($browser, 'safari') !== false) {
				$browser = 'Safari';
			} 
			elseif(stripos($browser, 'opera') !== false) {
				$browser = 'Opera';
			} 
			elseif(stripos($browser, 'firefox') !== false) {
				$browser = 'Firefox';
			}
            else
            {
                $browser = 'Other';
            }
            $cont = 0;
            foreach ($redirects as $storedrequest => $bundle[]) 
            {
                $bundle_values = array_values($bundle); 
                $myValues = $bundle_values[$cont];
                $cont = $cont + 1;
                $array_my_values = array_values($myValues); 
                $destination = $array_my_values[0];
                $device = $array_my_values[1];
                $login = $array_my_values[2];
                $ip = $array_my_values[3];
                $country = $array_my_values[4];
                $language = $array_my_values[5];
                $browserName = $array_my_values[6];
                $redirect = $array_my_values[7];
                $time = $array_my_values[8];
                $end_time = $array_my_values[9];
                $logging = $array_my_values[10];
                $active = $array_my_values[11];
                $wildcard = $array_my_values[12];
                if($active === '1')
                {
                    if($browserName !== 'All')
                    {
                        if($browserName !== $browser)
                        {
                            icarus_debug_log_to_file("Rule browserName not good: " . $browserName . " and " . $browser, $enable_debug_log);
                            continue;
                        }
                    }
                    if($device != 'All')
                    {
                        if($device === 'Bot')
                        {
                            if($bot === false)
                            {
                                icarus_debug_log_to_file("Rule bot not good: " . $device . " and " . $bot, $enable_debug_log);
                                continue;
                            }
                        }
                        if($device === 'Mobile')
                        {
                            if($mobile === false)
                            {
                                icarus_debug_log_to_file("Rule mobile not good: " . $device . " and " . $mobile, $enable_debug_log);
                                continue;
                            }
                        }
                        if($device === 'Tablet')
                        {
                            if($tablet === false)
                            {
                                icarus_debug_log_to_file("Rule tablet not good: " . $device . " and " . $tablet, $enable_debug_log);
                                continue;
                            }
                        }
                        if($device === 'Desktop')
                        {
                            if($tablet === true || $mobile === true || $bot === true)
                            {
                                icarus_debug_log_to_file("Rule desktop not good: " . $device, $enable_debug_log);
                                continue;
                            }
                        }
                    }
                    if($login !== 'All')
                    {
                        if($login === 'Admin')
                        {
                            if(!current_user_can( 'manage_options' ))
                            {
                                icarus_debug_log_to_file("Rule admin not good: " . $login, $enable_debug_log);
                                continue;
                            }
                        }
                        if($login === 'NotAdmin')
                        {
                            if(current_user_can( 'manage_options' ))
                            {
                                icarus_debug_log_to_file("Rule notadmin not good: " . $login, $enable_debug_log);
                                continue;
                            }
                        }
                        if($login === 'LoggedIn')
                        {
                            if(!is_user_logged_in())
                            {
                                icarus_debug_log_to_file("Rule login not good: " . $login, $enable_debug_log);
                                continue;
                            }
                        }
                        if($login === 'NotLoggedIn')
                        {
                            if(is_user_logged_in())
                            {
                                icarus_debug_log_to_file("Rule notlogin not good: " . $login, $enable_debug_log);
                                continue;
                            }
                        }
                    }
                    if($ip !== '')
                    {
                        $userIp = icarus_get_the_user_ip();
                        if($userIp !== $ip)
                        {
                            icarus_debug_log_to_file("Rule ip not good: " . $userIp . " and " . $ip, $enable_debug_log);
                            continue;
                        }
                    }
                    if($country !== 'ALL')
                    {
                        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                            $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
                        } else {
                            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                                $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                            } else {
                                $real_ip_adress = $_SERVER['REMOTE_ADDR'];
                            }
                        }
                        $country_code = icarus_ip_info($real_ip_adress, "Country Code");
                        if(strcasecmp($country, $country_code) != 0)
                        {
                            icarus_debug_log_to_file("Rule country not good: " . $country . " and " . $country_code, $enable_debug_log);
                            continue;
                        }
                    }
                    if($language != 'ALL')
                    {
                        $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
                        if(strcasecmp($language, $lang) != 0)
                        {
                            icarus_debug_log_to_file("Rule language not good: " . $language . " and " . $lang, $enable_debug_log);
                            continue;
                        }
                    }
                    if($time !== '' && $end_time !== '')
                    {
                        $date1 = new DateTime();
                        $date2 = DateTime::createFromFormat('H:ia', $time);
                        $date3 = DateTime::createFromFormat('H:ia', $end_time);
                        if ($date1 < $date2 || $date1 > $date3)
                        {
                            icarus_debug_log_to_file("Rule date not good: " . $date1->format('Y-m-d H:ia') . " and " . $date2->format('Y-m-d H:ia') . " and " . $date3->format('Y-m-d H:ia'), $enable_debug_log);
                            continue;
                        }
                    }
                    $do_redirect = '';
                    $userrequest = icarus_get_final_url($destination);
                    
                    if($actual_link !== $userrequest)
                    {
                        if ($wildcard === '1') {
                            if ( strpos($storedrequest, '/wp-login') !== 0 && strpos($storedrequest, '/wp-admin') !== 0 ) 
                            {
                                if (fnmatch($storedrequest, $short_url)) {
                                    icarus_debug_log_to_file("Wildcard match: " . $storedrequest . " and " . $short_url, $enable_debug_log);
                                    $do_redirect = $userrequest;
                                }
                            }
                        }
                        else
                        {
                            if(rtrim($short_url,'/') === rtrim($storedrequest,'/'))
                            {
                                icarus_debug_log_to_file("Direct match: " . $short_url . " and " . $storedrequest, $enable_debug_log);
                                $do_redirect = $destination;
                            }
                        }
                        if($do_redirect !== '')
                        {
                            if (trim($actual_link,'/') !== trim($userrequest,'/')) 
                            {
                                if (strpos($do_redirect,'/') === 0)
                                {
                                    $do_redirect = home_url().$do_redirect;
                                }
                                if($logging === '1')
                                {
                                    icarus_log_to_file("Redirecting user from ". $storedrequest . " to " . $do_redirect . " with redirect type: " . $redirect);
                                }
                                if (!headers_sent()) {
                                    if($redirect === '301')
                                    {
                                        header("HTTP/1.1 301 Moved Permanently");
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header("Status: 301 Moved Permanently");
                                        header("Location: " . $do_redirect);
                                        header("Connection: close");
                                    }
                                    if($redirect === '302')
                                    {
                                        // 302 Found
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header("Location: " . $do_redirect,TRUE,302);
                                        header("Location: " . $do_redirect);
                                        header("Connection: close");
                                    }
                                    if($redirect === '303')
                                    {
                                        // 303 See Other
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header("Location: " . $do_redirect,TRUE,303);
                                        header("Connection: close");
                                    }
                                    if($redirect === '307')
                                    {
                                        // 307 Temporary Redirect
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header("Location: " . $do_redirect,TRUE,307);
                                        header("Connection: close");
                                    }
                                    if($redirect === '403')
                                    {
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header('HTTP/1.0 403 Forbidden');
                                        header("Status: 403 Forbidden");
                                        if($do_redirect !== '')
                                        {
                                            header("Location: " . $do_redirect);
                                        }
                                        header("Connection: close");
                                    }
                                    if($redirect === '404')
                                    {
                                        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
                                        header("HTTP/1.0 404 Not Found");
                                        header("Status: 404 Not Found");
                                        if($do_redirect !== '')
                                        {
                                            header("Location: " . $do_redirect);
                                        }
                                        header("Connection: close");
                                    }
                                    exit(0);
                                }
                                else
                                {
                                    icarus_debug_log_to_file("Headers already sent! " . $do_redirect, $enable_debug_log);
                                    icarus_wp_redirect($do_redirect);
                                }
                            }
                        }
                    }
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_enable']) && $icarus_Main_Settings['redirect_enable'] === 'on')
        {
            if ( !is_404() )
            {
                return;
            }
            $get_params = "";
            if ( preg_match("@/?(\?.*)@", $_SERVER["REQUEST_URI"], $matches) ) {
                $get_params = $matches[1];
            }
            
            $patterns_array = array();
            $patterns_array[] = "/(trackback|feed|(comment-)?page-?[0-9]*)/?$";
            $patterns_array[] = "\.(html|php)$";
            $patterns_array[] = "/?\?.*";
            $patterns_array = array_map(create_function('$a', '$sep = (strpos($a, "@") === false ? "@" : "%"); return $sep.trim($a).$sep."i";'), $patterns_array);
            
            $search = preg_replace( $patterns_array, "", urldecode( $_SERVER["REQUEST_URI"] ) );
            $search = basename(trim($search));
            $search = str_replace("_", "-", $search);
            $search = trim(preg_replace( $patterns_array, "", $search));
            
            if ( !$search ) return;
            
            $search_words = trim(preg_replace( "@[_-]@", " ", $search));
            $GLOBALS["__icarus"]["search_words"] = explode(" ", $search_words);
            $GLOBALS["__icarus"]["suggestions"] = array();

            $search_groups = array("posts","pages","tags","categories");
            
            foreach ( $search_groups as $group ) {
                switch ( $group ) {
                    case "posts":
                        $posts = get_posts( array( "name" => $search, "post_type" => "post" ) );
                        if ( count( $posts ) == 1 ) {
                            icarus_debug_log_to_file("Redirecting to nearest match in posts!", $enable_debug_log);
                            icarus_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                        }
                        break;
                        
                    case "pages":
                        $posts = get_posts( array( "name" => $search, "post_type" => "page" ) );
                        if ( count( $posts ) == 1 ) {
                            icarus_debug_log_to_file("Redirecting to nearest match in pages!", $enable_debug_log);
                            icarus_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                        }
                        break;
                        
                    case "tags":
                        $tags = get_tags( array ( "name__like" => $search ) );
                        if ( count($tags) == 1) {
                            icarus_debug_log_to_file("Redirecting to nearest match in tags!", $enable_debug_log);
                            icarus_wp_redirect(get_tag_link($tags[0]->term_id) . $get_params, 301);
                        }
                        break;
                        
                    case "categories":
                        $categories = get_categories( array ( "name__like" => $search ) );
                        if ( count($categories) == 1) {
                            icarus_debug_log_to_file("Redirecting to nearest match in categories!", $enable_debug_log);
                            icarus_wp_redirect(get_category_link($categories[0]->term_id) . $get_params, 301);
                        }
                        break;
                }
            }
            
            foreach ( $search_groups as $group ) {
                switch ( $group ) {
                    case "posts":
                        $posts = icarus_search($search, "post");
                        if ( count( $posts ) == 1 ) {
                            icarus_debug_log_to_file("Redirecting to broad nearest match in posts!", $enable_debug_log);
                            icarus_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                        }

                        $GLOBALS["__icarus"]["suggestions"] = array_merge ( (array)$GLOBALS["__icarus"]["suggestions"], $posts );
                        break;
                        
                    case "pages":
                        $posts = icarus_search($search, "page");
                        if ( count( $posts ) == 1 ) {
                            icarus_debug_log_to_file("Redirecting to broad nearest match in pages!", $enable_debug_log);
                            icarus_wp_redirect( get_permalink( $posts[0]->ID ) . $get_params, 301 );
                        }

                        $GLOBALS["__icarus"]["suggestions"] = array_merge ( (array)$GLOBALS["__icarus"]["suggestions"], $posts );
                        break;
                }
            }
        }
        if(isset($icarus_Main_Settings['redirect_404_enable']) && $icarus_Main_Settings['redirect_404_enable'] === 'on')
        {
            $redirect_404_link = $icarus_Main_Settings['redirect_404_link'];
            if(isset($redirect_404_link) && $redirect_404_link !== '')
            {
                icarus_debug_log_to_file("Redirecting to 404 page! " . $redirect_404_link, $enable_debug_log);
                icarus_wp_redirect($redirect_404_link, 301);
            }
        }
    }
}
if(!function_exists('fnmatch')) {

    function fnmatch($pattern, $string) {
        return preg_match("#^".strtr(preg_quote($pattern, '#'), array('\*' => '.*', '\?' => '.'))."$#i", $string);
    }

}

if(!function_exists('str_ireplace')){
  function str_ireplace($search,$replace,$subject){
    $token = chr(1);
    $haystack = strtolower($subject);
    $needle = strtolower($search);
    while (($pos=strpos($haystack,$needle))!==FALSE){
      $subject = substr_replace($subject,$token,$pos,strlen($search));
      $haystack = substr_replace($haystack,$token,$pos,strlen($search));
    }
    $subject = str_replace($token,$replace,$subject);
    return $subject;
  }
}
add_action('admin_enqueue_scripts', 'icarus_admin_load_files');
function icarus_admin_load_files()
{
    wp_register_style('icarus-browser-style', plugins_url('styles/icarus-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('icarus-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('icarus-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('icarus-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('icarus-settings-app', plugins_url('res/icarus-angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('icarus-bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array(), '1.0.0', true);
    
    wp_enqueue_script('icarus-time-picker', plugins_url('res/jquery.timepicker.js', __FILE__), array(), '1.0.0', true);
    wp_register_style('icarus-browser-style2', plugins_url('styles/jquery.timepicker.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('icarus-browser-style2');
    wp_enqueue_script('icarus-time-picker2', plugins_url('res/bootstrap-datepicker.js', __FILE__), array(), '1.0.0', true);
    wp_register_style('icarus-browser-style21', plugins_url('styles/bootstrap-datepicker.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('icarus-browser-style21');
    
    wp_enqueue_script('icarus-date-picker', plugins_url('res/jquery.datepair.js', __FILE__), array(), '1.0.0', true);
}

function icarus_search($search, $type) {
    $search_words = trim(preg_replace( "@[_-]@", " ", $search));
	$posts = get_posts( array( "s" => $search_words, "post_type" => $type ) );
	if ( count( $posts ) > 1 ) {
	    $titlematches = array();
	    foreach ( $posts as $post ) {
	        if ( strpos(strtolower($post->post_title), strtolower($search_words)) !== false ) {
	            $titlematches[] = $post;
	        }
	    }
	    if ( count($titlematches) == 1 ) {
	        return $titlematches;
	    }
	}
	
	return $posts;
}

function icarus_has_suggestions() {
	return ( isset ( $GLOBALS["__icarus"]["suggestions"] ) && is_array( $GLOBALS["__icarus"]["suggestions"] ) && count( $GLOBALS["__icarus"]["suggestions"] ) > 0 ); 
}

function icarus_get_suggestions() {
	return $GLOBALS["__icarus"]["suggestions"];
}

function icarus_suggestions($format = 'flat') {
	if ( !isset ( $GLOBALS["__icarus"]["suggestions"] ) || !is_array( $GLOBALS["__icarus"]["suggestions"] ) || count( $GLOBALS["__icarus"]["suggestions"] ) == 0 ) 
		return false;
	
	echo '<div id="icarus_suggestions">';
	if ( $format == 'list' )
		echo '<ul>';
		
	foreach ( (array) $GLOBALS["__icarus"]["suggestions"] as $post ) {
		if ( $format == "list" )
			echo '<li>';
			
		?>
		<a href="<?php echo get_permalink($post->ID); ?>"><?php echo $post->post_title; ?></a>
		<?php
		
		if ( $format == "list" )
			echo '</li>';
		else if ( $format == "flat" )
			echo '<br />';
	}
	
	if ( $format == 'list ')
		echo '</ul>';
		
	echo '</div>';
	
	return true;
}

function icarus_ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array(
        "name",
        "\n",
        "\t",
        " ",
        "-",
        "_"
    ), NULL, strtolower(trim($purpose)));
    $support    = array(
        "country",
        "countrycode",
        "state",
        "region",
        "city",
        "location",
        "address"
    );
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array(
                        $ipdat->geoplugin_countryName
                    );
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

function icarus_getOS() { 
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'      =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );
    foreach ($os_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }   
    return $os_platform;
}

function icarus_log_to_file ($str) {
  $d = date("j-M-Y H:i:s e");
  error_log("[$d] $str" . '\r\n', 3, WP_CONTENT_DIR . '/icarus_info.log');
}
function icarus_debug_log_to_file ($str, $enable) {
  if($enable === 'on')
  {
      $d = date("j-M-Y H:i:s e");
      error_log("[$d] $str" . '\r\n', 3, WP_CONTENT_DIR . '/icarus_debug.log');
  }
}

function icarus_loop() {
	if ( !isset ( $GLOBALS["__icarus"]["suggestions"] ) || !is_array( $GLOBALS["__icarus"]["suggestions"] ) || count( $GLOBALS["__icarus"]["suggestions"] ) == 0 ) {
		return false;
	}
	
	$postids = array_map(create_function('$a', 'return $a->ID;'), $GLOBALS["__icarus"]["suggestions"]);
	
	query_posts( array( "post__in" => $postids ) );
	return have_posts();
}

function icarus_get_search_terms() {
    return $GLOBALS["__icarus"]["search_words"];
}

function icarus_get_the_user_ip() {

    if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) 
    {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) 
    {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else 
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return apply_filters( 'wpb_get_ip', $ip );
}

require(dirname(__FILE__) . "/res/icarus-main.php");
require(dirname(__FILE__) . "/res/icarus-logs.php");
require(dirname(__FILE__) . "/res/icarus-browser-detector.php");
?>