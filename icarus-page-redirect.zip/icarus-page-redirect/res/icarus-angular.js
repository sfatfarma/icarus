angular.module('icasettingsApp', ['ngSanitize'])
.controller('icasettingsController', function($scope) {
    $scope.settings = icarus_admin_json;
});