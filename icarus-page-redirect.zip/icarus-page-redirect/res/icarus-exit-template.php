<?php
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exit Strategy Page</title>
    <?php
    if(isset($_GET["timeout"]) && isset($_GET["url"]) && $_GET["timeout"] !== '-1')
    {
    ?>
        <meta http-equiv="refresh" content="<?php echo $_GET["timeout"]; ?>; url=<?php echo $_GET["url"]; ?>">
    <?php
    }
    ?>
<style>
* { margin: 0; 	padding: 0; }
body { height:100%;font-family: Georgia, Arial, Helvetica, Sans Serif; font-size: 65.5%; 
<?php
if(isset($_GET["image"]) && $_GET["image"] !== '-1')
{
?>
background-image: url(<?php echo $_GET["image"];?>);
<?php
}
else
{
?>
background-image: url(../images/yellow.jpg);
<?php
}
?>
  background-position: center center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: #464646;
}
a
{
<?php
if(isset($_GET["color"]) && $_GET["color"] !== '-1')
{
?>
color: <?php echo $_GET["color"];?>;
<?php
}
else
{
?>
color: #08658F;
<?php
}
?>
}
a:hover
{
<?php
if(isset($_GET["hover"])  && $_GET["hover"] !== '-1')
{
?>
color: <?php echo $_GET["hover"];?>;
<?php
}
else
{
?>
color: #0092BF;
<?php
}
?>
}
#header { color: #333; padding: 1.5em; text-align: center; font-size: 1.2em; border-bottom: 1px solid #08658F; }
#content { font-size: 150%; width:80%; margin:0 auto; padding: 5% 0; text-align: center; }
#content p { font-size: 1em; padding: .8em 0; }
h1, h2 { color: #08658F; }
h1 { font-size: 300%; padding: .5em 0; }
.icon-bar {
    margin:15px 0px 0px 0px;
    width: 80px;
    text-align: center;
    background-color: #555;
}

.icon-bar a {
    padding: 16px;
    display: block;
    transition: all 0.3s ease;
    color: white;
    font-size: 36px;
}

.icon-bar a:hover {
    background-color: #000;
}

.active {
    background-color: #4CAF50 !important;
}
</style>
</head>
<body>
    <div id="content">
        <?php
        if(isset($_GET["url"]) && isset($_GET["text"]))
        {
        ?>
            <h1><a href="<?php echo $_GET["url"];?>"><?php echo $_GET["text"]?></a></h1>
        <?php
        }
        if(isset($_GET["html"]) && $_GET["html"] !== '-1')
        {
            echo $_GET["html"];
        }
        if(isset($_GET["facebook"]) && $_GET["facebook"] !== '-1' && $_GET["facebook"] !== '0')
        {
        ?>
        <p>
        <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="<?php $root = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/';echo $root;?>" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="true"></div>
        </p>
        <?php
        }
        if(isset($_GET["twitter"]) && $_GET["twitter"] !== '-1' && $_GET["twitter"] !== '0')
        {
        ?>
        <p>
        <a href="https://twitter.com/share" class="twitter-share-button" data-show-count="false">Tweet</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
        </p>
        <?php
        }
        if(isset($_GET["google"]) && $_GET["google"] !== '-1' && $_GET["google"] !== '0')
        {
        ?>
        <p>
        <script src="https://apis.google.com/js/platform.js" async defer></script>
        <div class="g-plusone" data-size="tall"></div>
        </p>
        <?php
        }
        ?>
    </div>
</body>
</html>