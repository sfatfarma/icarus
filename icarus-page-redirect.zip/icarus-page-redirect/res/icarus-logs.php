<?php

function icarus_admin_logs()
{
    if(isset($_POST['icarus_delete']))
    {
        if(file_exists(WP_CONTENT_DIR . '/icarus_info.log'))
        {
            unlink(WP_CONTENT_DIR . '/icarus_info.log');
        }
        if(file_exists(WP_CONTENT_DIR . '/icarus_debug.log'))
        {
            unlink(WP_CONTENT_DIR . '/icarus_debug.log');
        }
    }
?>

<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="admin.php?page=icarus_admin_logs">

<script>
                var icarus_admin_json = { 
}
</script>
<p><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the main log of your plugin. Here will be listed every single redirect that was made on your website (if you enable logging for the rule you want to track, in the plugin configuration).";
?>
                        </div>
                    </div><b>Activity Log:</b></p>
<div>
<?php
if(file_exists(WP_CONTENT_DIR . '/icarus_info.log'))
{
    $log = file_get_contents(WP_CONTENT_DIR . '/icarus_info.log');
    echo $log;
}
else
{
    echo "Log empty";
}
?>
</div>
<p><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the debug log of your plugin. Please enable this feature (from the plugin control panel) only if requested by the plugin developer.";
?>
                        </div>
                    </div><b>Debug Log:</b></p>
<div>
<?php
if(file_exists(WP_CONTENT_DIR . '/icarus_debug.log'))
{
    $log = file_get_contents(WP_CONTENT_DIR . '/icarus_debug.log');
    echo $log;
}
else
{
    echo "Log empty";
}
?>
</div>
<br/><br/>
<form method="post">
   <input name="icarus_delete" type="submit" value="Delete Logs">
</form>    
</form>
</div>
</div>
<?php
}
?>