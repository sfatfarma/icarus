<?php

function icarus_admin_logs()
{
    if(isset($_POST['icarus_delete']))
    {
        if(file_exists(WP_CONTENT_DIR . '/icarus_info.log'))
        {
            unlink(WP_CONTENT_DIR . '/icarus_info.log');
        }
        if(file_exists(WP_CONTENT_DIR . '/icarus_debug.log'))
        {
            unlink(WP_CONTENT_DIR . '/icarus_debug.log');
        }
    }
?>

<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="admin.php?page=icarus_admin_logs">

<script>
                var icarus_admin_json = { 
}
</script>
<p><b>Activity Log:</b></p>
<div>
<?php
if(file_exists(WP_CONTENT_DIR . '/icarus_info.log'))
{
    $log = file_get_contents(WP_CONTENT_DIR . '/icarus_info.log');
    echo $log;
}
else
{
    echo "Log empty";
}
?>
</div>
<p><b>Debug Log:</b></p>
<div>
<?php
if(file_exists(WP_CONTENT_DIR . '/icarus_debug.log'))
{
    $log = file_get_contents(WP_CONTENT_DIR . '/icarus_debug.log');
    echo $log;
}
else
{
    echo "Log empty";
}
?>
</div>
<br/><br/>
<form method="post">
   <input name="icarus_delete" type="submit" value="Delete Logs">
</form>    
</form>
</div>
</div>
<?php
}
?>