<?php
$name = get_bloginfo('name');
$url = get_bloginfo('url');
$icarus_Main_Settings = get_option('icarus_Main_Settings', false);
$style = $icarus_Main_Settings['redirect_maintenance_style'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <title><?php echo $name; ?> &#8250; Maintenance Mode</title>
    <link rel="stylesheet" href="<?php 
    if($style === 'Plain')
    {
        echo ICARUS_MAINTENANCE_CSS_PLAIN;
    }
    elseif($style === 'White')
    {
        echo ICARUS_MAINTENANCE_CSS_WHITE;
    }
    elseif($style === 'Black')
    {
        echo ICARUS_MAINTENANCE_CSS_BLACK;
    }
    elseif($style === 'Red')
    {
        echo ICARUS_MAINTENANCE_CSS_RED;
    }
    elseif($style === 'Green')
    {
        echo ICARUS_MAINTENANCE_CSS_GREEN;
    }
    elseif($style === 'Blue')
    {
        echo ICARUS_MAINTENANCE_CSS_BLUE;
    }
    elseif($style === 'Yellow')
    {
        echo ICARUS_MAINTENANCE_CSS_YELLOW;
    }
?>" type="text/css" media="all" />	
<style>
.icon-bar {
    margin:15px 0px 0px 0px;
    width: 80px;
    text-align: center;
    background-color: #555;
}

.icon-bar a {
    padding: 16px;
    display: block;
    transition: all 0.3s ease;
    color: white;
    font-size: 36px;
}

.icon-bar a:hover {
    background-color: #000;
}

.active {
    background-color: #4CAF50 !important;
}
</style>
</head>
<body>
    <div id="header">
        <h2><a title="<?php echo $name; ?>" href="<?php echo $url; ?>"><?php echo $name; ?></a></h2>
    </div>	
    <div class="icon-bar">
  <a href="<?php echo wp_login_url(); ?>"><i class="fa fa-cogs"></i></a> 
</div>
    <div id="content">
        <h1><?php echo $icarus_Main_Settings['redirect_maintenance_title'];?></h1>
        <p><?php echo $icarus_Main_Settings['redirect_maintenance_name'];?></p>
    </div>
</body>
</html>