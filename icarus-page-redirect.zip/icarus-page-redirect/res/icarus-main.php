<?php
function icarus_save_redirects($data) {
            check_admin_referer( 'icarus_save_redirects', '_icarusr_nonce' );
			$data = $_POST['icarus_301_redirects'];

			$redirects = array();
			
			for($i = 0; $i < sizeof($data['request']); ++$i) {
                $bundle = array();
				$request = trim( sanitize_text_field( $data['request'][$i] ) );
				$bundle[] = trim( sanitize_text_field( $data['destination'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['device'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['login'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['ip'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['country'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['language'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['browser'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['redirect'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['time'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['end_time'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['logging'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['active'][$i] ) );
                $bundle[] = trim( sanitize_text_field( $data['wildcard'][$i] ) );
				if ($request == '') { continue; }
				else { $redirects[$request] = $bundle; }
			}
			
			update_option('icarus_301_redirects', $redirects);
		}
      
function icarus_expand_scripts() {   
    $output = '';
    $redirects = get_option('icarus_301_redirects');
	$output = '';
    $cont = 1;
    if (!empty($redirects)) {
        foreach ($redirects as $request => $bundle[]) {
            $output .= "jQuery('#basicExample" . $cont. "').timepicker();";
            $output .= "jQuery('#endExample" . $cont. "').timepicker();";
            $cont = $cont + 1;
        }
    }
    return $output;
}

function icarus_expand_redirects() {
			$redirects = get_option('icarus_301_redirects');
			$output = '';
            $cont = 0;
			if (!empty($redirects)) {
				foreach ($redirects as $request => $bundle[]) {
                    $bundle_values = array_values($bundle); 
                    $myValues = $bundle_values[$cont];
                    $cont = $cont + 1;
                    $array_my_values = array_values($myValues); 
                    $destination = $array_my_values[0];
                    $device = $array_my_values[1];
                    $login = $array_my_values[2];
                    $ip = $array_my_values[3];
                    $country = $array_my_values[4];
                    $language = $array_my_values[5];
                    $browser = $array_my_values[6];
                    $redirect = $array_my_values[7];
                    $time = $array_my_values[8];
                    $end_time = $array_my_values[9];
                    $logging = $array_my_values[10];
                    $active = $array_my_values[11];
                    $wildcard = $array_my_values[12];
                    
					$output .= '
					<tr>
						<td style="min-width:100px;"><input type="text" pattern="[/][^/].*" name="icarus_301_redirects[request][]" value="'.$request.'" style="width:99%" /></td>
                        <td style="max-width:20px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[wildcard][]" value="1" ';
                        if(isset($wildcard) && 
                           $wildcard === '1') 
                        {
                            $output .= ' checked';
                        }
                        $output .= '/></td>
						<td style="min-width:100px;"><input type="url" validator="url" name="icarus_301_redirects[destination][]" value="'.$destination.'" style="width:99%;"/></td>
						<td style="max-width:20px;text-align: center;" ><span class="wpicarus-delete"></span></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[device][]">
                        <option value="All" ';
                        if($device === 'All')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>All</option>
                        <option value="Mobile" ';
                        if($device === 'Mobile')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Mobile</option>
                        <option value="Tablet" ';
                        if($device === 'Tablet')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Tablet</option>
                        <option value="Desktop" ';
                        if($device === 'Desktop')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Desktop</option>
                        <option value="Bot" ';
                        if($device === 'Bot')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Bot</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[login][]">
                        <option value="All" ';
                        if($login === 'All')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>All</option>
                        <option value="LoggedIn" ';
                        if($login === 'LoggedIn')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>LoggedIn</option>
                        <option value="NotLoggedIn" ';
                        if($login === 'NotLoggedIn')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>NotLoggedIn</option>
                        <option value="Admin" ';
                        if($login === 'Admin')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Admin</option>
                        <option value="NotAdmin" ';
                        if($login === 'NotAdmin')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>NotAdmin</option>
                        </select></td>
                        <td style="min-width:80px;width:80px;text-align:center;vertical-align: middle;"><input type="text" pattern="^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$" name="icarus_301_redirects[ip][]" value="'. $ip . '" style="width:99%;" /></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[country][]">
                            <option value="ALL" ';
                            if($country === 'ALL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>ALL</option>
                            <option value="AF" ';
                            if($country === 'AF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Afghanistan</option>
                            <option value="AX" ';
                            if($country === 'AX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Åland Islands</option>
                            <option value="AL" ';
                            if($country === 'AL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Albania</option>
                            <option value="DZ" ';
                            if($country === 'DZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Algeria</option>
                            <option value="AS" ';
                            if($country === 'AS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>American Samoa</option>
                            <option value="AD" ';
                            if($country === 'AD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Andorra</option>
                            <option value="AO" ';
                            if($country === 'AO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Angola</option>
                            <option value="AI" ';
                            if($country === 'AI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Anguilla</option>
                            <option value="AQ" ';
                            if($country === 'AQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Antarctica</option>
                            <option value="AG" ';
                            if($country === 'AG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Antigua and Barbuda</option>
                            <option value="AR" ';
                            if($country === 'AR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Argentina</option>
                            <option value="AM" ';
                            if($country === 'AM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Armenia</option>
                            <option value="AW" ';
                            if($country === 'AW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Aruba</option>
                            <option value="AU" ';
                            if($country === 'AU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Australia</option>
                            <option value="AT" ';
                            if($country === 'AT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Austria</option>
                            <option value="AZ" ';
                            if($country === 'AZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Azerbaijan</option>
                            <option value="BS" ';
                            if($country === 'BS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bahamas</option>
                            <option value="BH" ';
                            if($country === 'BH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bahrain</option>
                            <option value="BD" ';
                            if($country === 'BD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bangladesh</option>
                            <option value="BB" ';
                            if($country === 'BB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Barbados</option>
                            <option value="BB" ';
                            if($country === 'BB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belarus</option>
                            <option value="BE" ';
                            if($country === 'BE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belgium</option>
                            <option value="BZ" ';
                            if($country === 'BZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Belize</option>
                            <option value="BJ" ';
                            if($country === 'BJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Benin</option>
                            <option value="BM" ';
                            if($country === 'BM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bermuda</option>
                            <option value="BT" ';
                            if($country === 'BT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bhutan</option>
                            <option value="BO" ';
                            if($country === 'BO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bolivia, Plurinational State of</option>
                            <option value="BQ" ';
                            if($country === 'BQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bonaire, Sint Eustatius and Saba</option>
                            <option value="BA" ';
                            if($country === 'BA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bosnia and Herzegovina</option>
                            <option value="BW" ';
                            if($country === 'BW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Botswana</option>
                            <option value="BV" ';
                            if($country === 'BV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bouvet Island</option>
                            <option value="BR" ';
                            if($country === 'BR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Brazil</option>
                            <option value="IO" ';
                            if($country === 'IO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>British Indian Ocean Territory</option>
                            <option value="BN" ';
                            if($country === 'BN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Brunei Darussalam</option>
                            <option value="BG" ';
                            if($country === 'BG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bulgaria</option>
                            <option value="BF" ';
                            if($country === 'BF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Burkina Faso</option>
                            <option value="BI" ';
                            if($country === 'BI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Burundi</option>
                            <option value="KH" ';
                            if($country === 'KH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cambodia</option>
                            <option value="CM" ';
                            if($country === 'CM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cameroon</option>
                            <option value="CA" ';
                            if($country === 'CA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Canada</option>
                            <option value="CV" ';
                            if($country === 'CV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cape Verde</option>
                            <option value="KY" ';
                            if($country === 'KY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cayman Islands</option>
                            <option value="CF" ';
                            if($country === 'CF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Central African Republic</option>
                            <option value="TD" ';
                            if($country === 'TD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chad</option>
                            <option value="CL" ';
                            if($country === 'CL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chile</option>
                            <option value="CN" ';
                            if($country === 'CN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>China</option>
                            <option value="CX" ';
                            if($country === 'CX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Christmas Island</option>
                            <option value="CC" ';
                            if($country === 'CC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cocos (Keeling) Islands</option>
                            <option value="CO" ';
                            if($country === 'CO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Colombia</option>
                            <option value="KM" ';
                            if($country === 'KM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Comoros</option>
                            <option value="CG" ';
                            if($country === 'CG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Congo</option>
                            <option value="CD" ';
                            if($country === 'CD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Congo, the Democratic Republic of the</option>
                            <option value="CK" ';
                            if($country === 'CK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cook Islands</option>
                            <option value="CR" ';
                            if($country === 'CR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Costa Rica</option>
                            <option value="CI" ';
                            if($country === 'CI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Côte d\'Ivoire</option>
                            <option value="HR" ';
                            if($country === 'HR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Croatia</option>
                            <option value="CU" ';
                            if($country === 'CU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cuba</option>
                            <option value="CW" ';
                            if($country === 'CW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Curaçao</option>
                            <option value="CY" ';
                            if($country === 'CY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cyprus</option>
                            <option value="CZ" ';
                            if($country === 'CZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Czech Republic</option>
                            <option value="DK" ';
                            if($country === 'DK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Denmark</option>
                            <option value="DJ" ';
                            if($country === 'DJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Djibouti</option>
                            <option value="DM" ';
                            if($country === 'DM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dominica</option>
                            <option value="DO" ';
                            if($country === 'DO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dominican Republic</option>
                            <option value="EC" ';
                            if($country === 'EC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ecuador</option>
                            <option value="EG" ';
                            if($country === 'EG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Egypt</option>
                            <option value="SV" ';
                            if($country === 'SV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>El Salvador</option>
                            <option value="GQ" ';
                            if($country === 'GQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Equatorial Guinea</option>
                            <option value="ER" ';
                            if($country === 'ER')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Eritrea</option>
                            <option value="EE" ';
                            if($country === 'EE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Estonia</option>
                            <option value="ET" ';
                            if($country === 'ET')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ethiopia</option>
                            <option value="FK" ';
                            if($country === 'FK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Falkland Islands (Malvinas)</option>
                            <option value="FO" ';
                            if($country === 'FO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Faroe Islands</option>
                            <option value="FJ" ';
                            if($country === 'FJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Fiji</option>
                            <option value="FI" ';
                            if($country === 'FI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Finland</option>
                            <option value="FR" ';
                            if($country === 'FR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>France</option>
                            <option value="GF" ';
                            if($country === 'GF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Guiana</option>
                            <option value="PF" ';
                            if($country === 'PF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Polynesia</option>
                            <option value="TF" ';
                            if($country === 'TF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French Southern Territories</option>
                            <option value="GA" ';
                            if($country === 'GA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gabon</option>
                            <option value="GM" ';
                            if($country === 'GM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gambia</option>
                            <option value="GE" ';
                            if($country === 'GE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Georgia</option>
                            <option value="DE" ';
                            if($country === 'DE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Germany</option>
                            <option value="GH" ';
                            if($country === 'GH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ghana</option>
                            <option value="GI" ';
                            if($country === 'GI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gibraltar</option>
                            <option value="GR" ';
                            if($country === 'GR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greece</option>
                            <option value="GL" ';
                            if($country === 'GL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greenland</option>
                            <option value="GD" ';
                            if($country === 'GD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Grenada</option>
                            <option value="GP" ';
                            if($country === 'GP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guadeloupe</option>
                            <option value="GU" ';
                            if($country === 'GU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guam</option>
                            <option value="GT" ';
                            if($country === 'GT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guatemala</option>
                            <option value="GG" ';
                            if($country === 'GG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guernsey</option>
                            <option value="GN" ';
                            if($country === 'GN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guinea</option>
                            <option value="GW" ';
                            if($country === 'GW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guinea-Bissau</option>
                            <option value="GY" ';
                            if($country === 'GY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Guyana</option>
                            <option value="HT" ';
                            if($country === 'HT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Haiti</option>
                            <option value="HM" ';
                            if($country === 'HM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Heard Island and McDonald Islands</option>
                            <option value="VA" ';
                            if($country === 'VA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Holy See (Vatican City State)</option>
                            <option value="HN" ';
                            if($country === 'HN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Honduras</option>
                            <option value="HK" ';
                            if($country === 'HK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hong Kong</option>
                            <option value="HU" ';
                            if($country === 'HU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hungary</option>
                            <option value="IS" ';
                            if($country === 'IS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iceland</option>
                            <option value="IN" ';
                            if($country === 'IN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>India</option>
                            <option value="ID" ';
                            if($country === 'ID')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Indonesia</option>
                            <option value="IR" ';
                            if($country === 'IR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iran, Islamic Republic of</option>
                            <option value="IQ" ';
                            if($country === 'IQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Iraq</option>
                            <option value="IE" ';
                            if($country === 'IE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ireland</option>
                            <option value="IM" ';
                            if($country === 'IM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Isle of Man</option>
                            <option value="IL" ';
                            if($country === 'IL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Israel</option>
                            <option value="IT" ';
                            if($country === 'IT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Italy</option>
                            <option value="JM" ';
                            if($country === 'JM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jamaica</option>
                            <option value="JP" ';
                            if($country === 'JP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Japan</option>
                            <option value="JE" ';
                            if($country === 'JE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jersey</option>
                            <option value="JO" ';
                            if($country === 'JO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Jordan</option>
                            <option value="KZ" ';
                            if($country === 'KZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kazakhstan</option>
                            <option value="KE" ';
                            if($country === 'KE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kenya</option>
                            <option value="KI" ';
                            if($country === 'KI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kiribati</option>
                            <option value="KP" ';
                            if($country === 'KP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korea, Democratic People\'s Republic of</option>
                            <option value="KR" ';
                            if($country === 'KR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korea, Republic of</option>
                            <option value="KW" ';
                            if($country === 'KW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kuwait</option>
                            <option value="KG" ';
                            if($country === 'KG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Kyrgyzstan</option>
                            <option value="LA" ';
                            if($country === 'LA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lao People\'s Democratic Republic</option>
                            <option value="LV" ';
                            if($country === 'LV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latvia</option>
                            <option value="LB" ';
                            if($country === 'LB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lebanon</option>
                            <option value="LS" ';
                            if($country === 'LS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lesotho</option>
                            <option value="LR" ';
                            if($country === 'LR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Liberia</option>
                            <option value="LY" ';
                            if($country === 'LY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Libya</option>
                            <option value="LI" ';
                            if($country === 'LI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Liechtenstein</option>
                            <option value="LT" ';
                            if($country === 'LT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lithuania</option>
                            <option value="LU" ';
                            if($country === 'LU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Luxembourg</option>
                            <option value="MO" ';
                            if($country === 'MO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macao</option>
                            <option value="MK" ';
                            if($country === 'MK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macedonia, the former Yugoslav Republic of</option>
                            <option value="MG" ';
                            if($country === 'MG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Madagascar</option>
                            <option value="MW" ';
                            if($country === 'MW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malawi</option>
                            <option value="MY" ';
                            if($country === 'MY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malaysia</option>
                            <option value="MV" ';
                            if($country === 'MV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maldives</option>
                            <option value="ML" ';
                            if($country === 'ML')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mali</option>
                            <option value="MT" ';
                            if($country === 'MT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malta</option>
                            <option value="MH" ';
                            if($country === 'MH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Marshall Islands</option>
                            <option value="MQ" ';
                            if($country === 'MQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Martinique</option>
                            <option value="MR" ';
                            if($country === 'MR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mauritania</option>
                            <option value="MU" ';
                            if($country === 'MU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mauritius</option>
                            <option value="YT" ';
                            if($country === 'YT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mayotte</option>
                            <option value="MX" ';
                            if($country === 'MX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mexico</option>
                            <option value="FM" ';
                            if($country === 'FM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Micronesia, Federated States of</option>
                            <option value="MD" ';
                            if($country === 'MD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Moldova, Republic of</option>
                            <option value="MC" ';
                            if($country === 'MC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Monaco</option>
                            <option value="MN" ';
                            if($country === 'MN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mongolia</option>
                            <option value="ME" ';
                            if($country === 'ME')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Montenegro</option>
                            <option value="MS" ';
                            if($country === 'MS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Montserrat</option>
                            <option value="MA" ';
                            if($country === 'MA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Morocco</option>
                            <option value="MZ" ';
                            if($country === 'MZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mozambique</option>
                            <option value="MM" ';
                            if($country === 'MM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Myanmar</option>
                            <option value="NA" ';
                            if($country === 'NA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Namibia</option>
                            <option value="NR" ';
                            if($country === 'NR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nauru</option>
                            <option value="NP" ';
                            if($country === 'NP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nepal</option>
                            <option value="NL" ';
                            if($country === 'NL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Netherlands</option>
                            <option value="NC" ';
                            if($country === 'NC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>New Caledonia</option>
                            <option value="NZ" ';
                            if($country === 'NZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>New Zealand</option>
                            <option value="NI" ';
                            if($country === 'NI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nicaragua</option>
                            <option value="NE" ';
                            if($country === 'NE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Niger</option>
                            <option value="NG" ';
                            if($country === 'NG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nigeria</option>
                            <option value="NU" ';
                            if($country === 'NU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Niue</option>
                            <option value="NF" ';
                            if($country === 'NF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norfolk Island</option>
                            <option value="MP" ';
                            if($country === 'MP')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Northern Mariana Islands</option>
                            <option value="NO" ';
                            if($country === 'NO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norway</option>
                            <option value="OM" ';
                            if($country === 'OM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Oman</option>
                            <option value="PK" ';
                            if($country === 'PK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Pakistan</option>
                            <option value="PW" ';
                            if($country === 'PW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Palau</option>
                            <option value="PS" ';
                            if($country === 'PS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Palestinian Territory, Occupied</option>
                            <option value="PA" ';
                            if($country === 'PA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Panama</option>
                            <option value="PG" ';
                            if($country === 'PG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Papua New Guinea</option>
                            <option value="PY" ';
                            if($country === 'PY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Paraguay</option>
                            <option value="PE" ';
                            if($country === 'PE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Peru</option>
                            <option value="PH" ';
                            if($country === 'PH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Philippines</option>
                            <option value="PN" ';
                            if($country === 'PN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Pitcairn</option>
                            <option value="PL" ';
                            if($country === 'PL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Poland</option>
                            <option value="PT" ';
                            if($country === 'PT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Portugal</option>
                            <option value="PR" ';
                            if($country === 'PR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Puerto Rico</option>
                            <option value="QA" ';
                            if($country === 'QA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Qatar</option>
                            <option value="RE" ';
                            if($country === 'RE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Réunion</option>
                            <option value="RO" ';
                            if($country === 'RO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Romania</option>
                            <option value="RU" ';
                            if($country === 'RU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Russian Federation</option>
                            <option value="RW" ';
                            if($country === 'RW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Rwanda</option>
                            <option value="BL" ';
                            if($country === 'BL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Barthélemy</option>
                            <option value="SH" ';
                            if($country === 'SH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Helena, Ascension and Tristan da Cunha</option>
                            <option value="KN" ';
                            if($country === 'KN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Kitts and Nevis</option>
                            <option value="LC" ';
                            if($country === 'LC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Lucia</option>
                            <option value="MF" ';
                            if($country === 'MF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Martin (French part)</option>
                            <option value="PM" ';
                            if($country === 'PM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Pierre and Miquelon</option>
                            <option value="VC" ';
                            if($country === 'VC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saint Vincent and the Grenadines</option>
                            <option value="WS" ';
                            if($country === 'WS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Samoa</option>
                            <option value="SM" ';
                            if($country === 'SM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>San Marino</option>
                            <option value="ST" ';
                            if($country === 'ST')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sao Tome and Principe</option>
                            <option value="SA" ';
                            if($country === 'SA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Saudi Arabia</option>
                            <option value="SN" ';
                            if($country === 'SN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Senegal</option>
                            <option value="RS" ';
                            if($country === 'RS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Serbia</option>
                            <option value="SC" ';
                            if($country === 'SC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Seychelles</option>
                            <option value="SL" ';
                            if($country === 'SL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sierra Leone</option>
                            <option value="SG" ';
                            if($country === 'SG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Singapore</option>
                            <option value="SX" ';
                            if($country === 'SX')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sint Maarten (Dutch part)</option>
                            <option value="SK" ';
                            if($country === 'SK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovakia</option>
                            <option value="SI" ';
                            if($country === 'SI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovenia</option>
                            <option value="SB" ';
                            if($country === 'SB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Solomon Islands</option>
                            <option value="SO" ';
                            if($country === 'SO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Somalia</option>
                            <option value="ZA" ';
                            if($country === 'ZA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Africa</option>
                            <option value="GS" ';
                            if($country === 'GS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Georgia and the South Sandwich Islands</option>
                            <option value="SS" ';
                            if($country === 'SS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>South Sudan</option>
                            <option value="ES" ';
                            if($country === 'ES')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Spain</option>
                            <option value="LK" ';
                            if($country === 'LK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sri Lanka</option>
                            <option value="SD" ';
                            if($country === 'SD')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sudan</option>
                            <option value="SR" ';
                            if($country === 'SR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Suriname</option>
                            <option value="SJ" ';
                            if($country === 'SJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Svalbard and Jan Mayen</option>
                            <option value="SZ" ';
                            if($country === 'SZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swaziland</option>
                            <option value="SE" ';
                            if($country === 'SE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Sweden</option>
                            <option value="CH" ';
                            if($country === 'CH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Switzerland</option>
                            <option value="SY" ';
                            if($country === 'SY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Syrian Arab Republic</option>
                            <option value="TW" ';
                            if($country === 'TW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Taiwan, Province of China</option>
                            <option value="TJ" ';
                            if($country === 'TJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tajikistan</option>
                            <option value="TZ" ';
                            if($country === 'TZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tanzania, United Republic of</option>
                            <option value="TH" ';
                            if($country === 'TH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Thailand</option>
                            <option value="TL" ';
                            if($country === 'TL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Timor-Leste</option>
                            <option value="TG" ';
                            if($country === 'TG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Togo</option>
                            <option value="TK" ';
                            if($country === 'TK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tokelau</option>
                            <option value="TO" ';
                            if($country === 'TO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tonga</option>
                            <option value="TT" ';
                            if($country === 'TT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Trinidad and Tobago</option>
                            <option value="TN" ';
                            if($country === 'TN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tunisia</option>
                            <option value="TR" ';
                            if($country === 'TR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkey</option>
                            <option value="TM" ';
                            if($country === 'TM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkmenistan</option>
                            <option value="TC" ';
                            if($country === 'TC')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turks and Caicos Islands</option>
                            <option value="TV" ';
                            if($country === 'TV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tuvalu</option>
                            <option value="UG" ';
                            if($country === 'UG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uganda</option>
                            <option value="UA" ';
                            if($country === 'UA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ukraine</option>
                            <option value="AE" ';
                            if($country === 'AE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United Arab Emirates</option>
                            <option value="GB" ';
                            if($country === 'GB')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United Kingdom</option>
                            <option value="US" ';
                            if($country === 'US')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United States of America</option>
                            <option value="UM" ';
                            if($country === 'UM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>United States Minor Outlying Islands</option>
                            <option value="UY" ';
                            if($country === 'UY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uruguay</option>
                            <option value="UZ" ';
                            if($country === 'UZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uzbekistan</option>
                            <option value="VU" ';
                            if($country === 'VU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Vanuatu</option>
                            <option value="VE" ';
                            if($country === 'VE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Venezuela, Bolivarian Republic of</option>
                            <option value="VN" ';
                            if($country === 'VN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Viet Nam</option>
                            <option value="VG" ';
                            if($country === 'VG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Virgin Islands, British</option>
                            <option value="VI" ';
                            if($country === 'VI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Virgin Islands, U.S.</option>
                            <option value="WF" ';
                            if($country === 'WF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Wallis and Futuna</option>
                            <option value="EH" ';
                            if($country === 'EH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Western Sahara</option>
                            <option value="YE" ';
                            if($country === 'YE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Yemen</option>
                            <option value="ZM" ';
                            if($country === 'ZM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Zambia</option>
                            <option value="ZW" ';
                            if($country === 'ZW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Zimbabwe</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[language][]">
                            <option value="ALL" ';
                            if($language === 'ALL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>ALL</option>
                            <option value="AF" ';
                            if($language === 'AF')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Afrikanns</option>
                            <option value="SQ" ';
                            if($language === 'SQ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Albanian</option>
                            <option value="AR" ';
                            if($language === 'AR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Arabic</option>
                            <option value="HY" ';
                            if($language === 'HY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Armenian</option>
                            <option value="EU" ';
                            if($language === 'EU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Basque</option>
                            <option value="BN" ';
                            if($language === 'BN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bengali</option>
                            <option value="BG" ';
                            if($language === 'BG')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Bulgarian</option>
                            <option value="CA" ';
                            if($language === 'CA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Catalan</option>
                            <option value="KM" ';
                            if($language === 'KM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Cambodian</option>
                            <option value="ZH" ';
                            if($language === 'ZH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Chinese (Mandarin)</option>
                            <option value="HR" ';
                            if($language === 'HR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Croation</option>
                            <option value="CS" ';
                            if($language === 'CS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Czech</option>
                            <option value="DA" ';
                            if($language === 'DA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Danish</option>
                            <option value="NL" ';
                            if($language === 'NL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Dutch</option>
                            <option value="EN" ';
                            if($language === 'EN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>English</option>
                            <option value="ET" ';
                            if($language === 'ET')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Estonian</option>
                            <option value="FJ" ';
                            if($language === 'FJ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Fiji</option>
                            <option value="FI" ';
                            if($language === 'FI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Finnish</option>
                            <option value="FR" ';
                            if($language === 'FR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>French</option>
                            <option value="KA" ';
                            if($language === 'KA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Georgian</option>
                            <option value="DE" ';
                            if($language === 'DE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>German</option>
                            <option value="EL" ';
                            if($language === 'EL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Greek</option>
                            <option value="GU" ';
                            if($language === 'GU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Gujarati</option>
                            <option value="HE" ';
                            if($language === 'HE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hebrew</option>
                            <option value="HI" ';
                            if($language === 'HI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hindi</option>
                            <option value="HU" ';
                            if($language === 'HU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Hungarian</option>
                            <option value="IS" ';
                            if($language === 'IS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Icelandic</option>
                            <option value="ID" ';
                            if($language === 'ID')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Indonesian</option>
                            <option value="GA" ';
                            if($language === 'GA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Irish</option>
                            <option value="IT" ';
                            if($language === 'IT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Italian</option>
                            <option value="JA" ';
                            if($language === 'JA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Japanese</option>
                            <option value="JW" ';
                            if($language === 'JW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Javanese</option>
                            <option value="KO" ';
                            if($language === 'KO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Korean</option>
                            <option value="LA" ';
                            if($language === 'LA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latin</option>
                            <option value="LV" ';
                            if($language === 'LV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Latvian</option>
                            <option value="LT" ';
                            if($language === 'LT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Lithuanian</option>
                            <option value="MK" ';
                            if($language === 'MK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Macedonian</option>
                            <option value="MS" ';
                            if($language === 'MS')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malay</option>
                            <option value="ML" ';
                            if($language === 'ML')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Malayalam</option>
                            <option value="MT" ';
                            if($language === 'MT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maltese</option>
                            <option value="MI" ';
                            if($language === 'MI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Maori</option>
                            <option value="MR" ';
                            if($language === 'MR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Marathi</option>
                            <option value="MN" ';
                            if($language === 'MN')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Mongolian</option>
                            <option value="NE" ';
                            if($language === 'NE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Nepali</option>
                            <option value="NO" ';
                            if($language === 'NO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Norwegian</option>
                            <option value="FA" ';
                            if($language === 'FA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Persian</option>
                            <option value="PL" ';
                            if($language === 'PL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Polish</option>
                            <option value="PT" ';
                            if($language === 'PT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Portuguese</option>
                            <option value="PA" ';
                            if($language === 'PA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Punjabi</option>
                            <option value="QU" ';
                            if($language === 'QU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Quechua</option>
                            <option value="RO" ';
                            if($language === 'RO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Romanian</option>
                            <option value="RU" ';
                            if($language === 'RU')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Russian</option>
                            <option value="SM" ';
                            if($language === 'SM')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Samoan</option>
                            <option value="SR" ';
                            if($language === 'SR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Serbian</option>
                            <option value="SK" ';
                            if($language === 'SK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovak</option>
                            <option value="SL" ';
                            if($language === 'SL')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Slovenian</option>
                            <option value="ES" ';
                            if($language === 'ES')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Spanish</option>
                            <option value="SW" ';
                            if($language === 'SW')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swahili</option>
                            <option value="SV" ';
                            if($language === 'SV')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Swedish </option>
                            <option value="TA" ';
                            if($language === 'TA')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tamil</option>
                            <option value="TT" ';
                            if($language === 'TT')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tatar</option>
                            <option value="TE" ';
                            if($language === 'TE')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Telugu</option>
                            <option value="TH" ';
                            if($language === 'TH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Thai</option>
                            <option value="BO" ';
                            if($language === 'BO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tibetan</option>
                            <option value="TO" ';
                            if($language === 'TO')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Tonga</option>
                            <option value="TR" ';
                            if($language === 'TR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Turkish</option>
                            <option value="UK" ';
                            if($language === 'UK')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Ukranian</option>
                            <option value="UR" ';
                            if($language === 'UR')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Urdu</option>
                            <option value="UZ" ';
                            if($language === 'UZ')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Uzbek</option>
                            <option value="VI" ';
                            if($language === 'VI')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Vietnamese</option>
                            <option value="CY" ';
                            if($language === 'CY')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Welsh</option>
                            <option value="XH" ';
                            if($language === 'XH')
                            {
                                $output .= 'selected="selected"';
                            }
                            $output .= '>Xhosa</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[browser][]">
                        <option value="All" ';
                        if($browser === 'All')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>All</option>
                        <option value="IE" ';
                        if($browser === 'IE')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>IE</option>
                        <option value="Egde" ';
                        if($browser === 'Edge')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Edge</option>
                        <option value="Chrome" ';
                        if($browser === 'Chrome')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Chrome</option>
                        <option value="Firefox" ';
                        if($browser === 'Firefox')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Firefox</option>
                        <option value="Opera" ';
                        if($browser === 'Opera')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Opera</option>
                        <option value="Safari" ';
                        if($browser === 'Safari')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Safari</option>
                        <option value="Other" ';
                        if($browser === 'Other')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>Other</option>
                        </select></td>
                        <td style="min-width:40px;width:40px;text-align:center;vertical-align: middle;"><input style="width: 50px;" type="text" name="icarus_301_redirects[time][]" id="basicExample' . $cont . '" class="time" value="'.$time.'" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/></td>
                        <td style="min-width:40px;width:40px;text-align:center;vertical-align: middle;"><input style="width: 50px;" type="text" name="icarus_301_redirects[end_time][]" id="endExample' . $cont . '" class="time" value="'.$end_time.'" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/></td>
                        <td style="max-width:30px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[logging][]" value="1" ';
                        if(isset($logging) && 
                           $logging === '1') 
                        {
                            $output .= ' checked';
                        }
                        $output .= '/></td>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[active][]" value="1" ';
                        if(isset($active) && 
                           $active === '1') 
                        {
                            $output .= ' checked';
                        }
                        $output .= '/></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[redirect][]">
                        <option value="301" ';
                        if($redirect === '301')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>301</option>
                        <option value="302" ';
                        if($redirect === '302')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>302</option>
                        <option value="303" ';
                        if($redirect === '303')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>303</option>
                        <option value="307" ';
                        if($redirect === '307')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>307</option>
                        <option value="403" ';
                        if($redirect === '403')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>403</option>
                        <option value="404" ';
                        if($redirect === '404')
                        {
                            $output .= 'selected="selected"';
                        }
                        $output .= '>404</option>
                        </select></td>
					</tr>	
					';
				}
			} // end if
			return $output;
		}

function icarus_admin_settings()
{
?>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    wp_nonce_field( 'icarus_save_redirects', '_icarusr_nonce' );
    settings_fields('icarus_option_group');
    do_settings_sections('icarus_option_group');
    $icarus_Main_Settings = get_option('icarus_Main_Settings', false);
    if (isset($icarus_Main_Settings['icarus_enabled'])) {
        $icarus_enabled = $icarus_Main_Settings['icarus_enabled'];
    } else {
        $icarus_enabled = '';
    }
    if (isset($icarus_Main_Settings['redirect_random'])) {
        $redirect_random = $icarus_Main_Settings['redirect_random'];
    } else {
        $redirect_random = '';
    }
    if (isset($icarus_Main_Settings['redirect_404_enable'])) {
        $redirect_404_enable = $icarus_Main_Settings['redirect_404_enable'];
    } else {
        $redirect_404_enable = '';
    }
    if (isset($icarus_Main_Settings['redirect_enable'])) {
        $redirect_enable = $icarus_Main_Settings['redirect_enable'];
    } else {
        $redirect_enable = '';
    }
    if (isset($icarus_Main_Settings['redirect_404_link'])) {
        $redirect_404_link = $icarus_Main_Settings['redirect_404_link'];
    } else {
        $redirect_404_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_random_url'])) {
        $redirect_random_url = $icarus_Main_Settings['redirect_random_url'];
    } else {
        $redirect_random_url = '/random-post';
    }
    if (isset($icarus_Main_Settings['start_time'])) {
        $start_time = $icarus_Main_Settings['start_time'];
    } else {
        $start_time = '';
    }
    if (isset($icarus_Main_Settings['end_time'])) {
        $end_time = $icarus_Main_Settings['end_time'];
    } else {
        $end_time = '';
    }
    if (isset($icarus_Main_Settings['start_date'])) {
        $start_date = $icarus_Main_Settings['start_date'];
    } else {
        $start_date = '';
    }
    if (isset($icarus_Main_Settings['end_date'])) {
        $end_date = $icarus_Main_Settings['end_date'];
    } else {
        $end_date = '';
    }
    if (isset($icarus_Main_Settings['redirect_enable_referrer'])) {
        $redirect_enable_referrer = $icarus_Main_Settings['redirect_enable_referrer'];
    } else {
        $redirect_enable_referrer = '';
    }
    if (isset($icarus_Main_Settings['redirect_time_based'])) {
        $redirect_time_based = $icarus_Main_Settings['redirect_time_based'];
    } else {
        $redirect_time_based = '';
    }
    if (isset($icarus_Main_Settings['redirect_referrer_link'])) {
        $redirect_referrer_link = $icarus_Main_Settings['redirect_referrer_link'];
    } else {
        $redirect_referrer_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_enable_username'])) {
        $redirect_enable_username = $icarus_Main_Settings['redirect_enable_username'];
    } else {
        $redirect_enable_username = '';
    }
    if (isset($icarus_Main_Settings['redirect_username'])) {
        $redirect_username = $icarus_Main_Settings['redirect_username'];
    } else {
        $redirect_username = '';
    }
    if (isset($icarus_Main_Settings['redirect_enable_os'])) {
        $redirect_enable_os = $icarus_Main_Settings['redirect_enable_os'];
    } else {
        $redirect_enable_os = '';
    }
    if (isset($icarus_Main_Settings['redirect_os'])) {
        $redirect_os = $icarus_Main_Settings['redirect_os'];
    } else {
        $redirect_os = '';
    }
    if (isset($icarus_Main_Settings['redirect_enable_log'])) {
        $redirect_enable_log = $icarus_Main_Settings['redirect_enable_log'];
    } else {
        $redirect_enable_log = '';
    }
    if (isset($icarus_Main_Settings['redirect_login'])) {
        $redirect_login = $icarus_Main_Settings['redirect_login'];
    } else {
        $redirect_login = '';
    }
    if (isset($icarus_Main_Settings['redirect_login_link'])) {
        $redirect_login_link = $icarus_Main_Settings['redirect_login_link'];
    } else {
        $redirect_login_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_logout'])) {
        $redirect_logout = $icarus_Main_Settings['redirect_logout'];
    } else {
        $redirect_logout = '';
    }
    if (isset($icarus_Main_Settings['redirect_logout_link'])) {
        $redirect_logout_link = $icarus_Main_Settings['redirect_logout_link'];
    } else {
        $redirect_logout_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance_name'])) {
        $redirect_maintenance_name = esc_textarea($icarus_Main_Settings['redirect_maintenance_name']);
    } else {
        $redirect_maintenance_name = '';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance_title'])) {
        $redirect_maintenance_title = esc_textarea($icarus_Main_Settings['redirect_maintenance_title']);
    } else {
        $redirect_maintenance_title = '';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance'])) {
        $redirect_maintenance = $icarus_Main_Settings['redirect_maintenance'];
    } else {
        $redirect_maintenance = '';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance_style'])) {
        $redirect_maintenance_style = $icarus_Main_Settings['redirect_maintenance_style'];
    } else {
        $redirect_maintenance_style = 'Plain';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance_text_color'])) {
        $redirect_maintenance_text_color = $icarus_Main_Settings['redirect_maintenance_text_color'];
    } else {
        $redirect_maintenance_text_color = '#000000';
    }
    if (isset($icarus_Main_Settings['redirect_maintenance_title_color'])) {
        $redirect_maintenance_title_color = $icarus_Main_Settings['redirect_maintenance_title_color'];
    } else {
        $redirect_maintenance_title_color = '#000000';
    }
    if (isset($icarus_Main_Settings['redirect_attachment'])) {
        $redirect_attachment = $icarus_Main_Settings['redirect_attachment'];
    } else {
        $redirect_attachment = '';
    }
    if (isset($icarus_Main_Settings['redirect_adblock_link'])) {
        $redirect_adblock_link = $icarus_Main_Settings['redirect_adblock_link'];
    } else {
        $redirect_adblock_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_adblock'])) {
        $redirect_adblock = $icarus_Main_Settings['redirect_adblock'];
    } else {
        $redirect_adblock = '';
    }
    if (isset($icarus_Main_Settings['redirect_comment_link'])) {
        $redirect_comment_link = $icarus_Main_Settings['redirect_comment_link'];
    } else {
        $redirect_comment_link = '';
    }
    if (isset($icarus_Main_Settings['redirect_comment'])) {
        $redirect_comment = $icarus_Main_Settings['redirect_comment'];
    } else {
        $redirect_comment = '';
    }
    if (isset($icarus_Main_Settings['redirect_http'])) {
        $redirect_http = $icarus_Main_Settings['redirect_http'];
    } else {
        $redirect_http = 'No';
    }
    if (isset($icarus_Main_Settings['redirect_www'])) {
        $redirect_www = $icarus_Main_Settings['redirect_www'];
    } else {
        $redirect_www = 'No';
    }
    if (isset($icarus_Main_Settings['redirect_clear_log'])) {
        $redirect_clear_log = $icarus_Main_Settings['redirect_clear_log'];
    } else {
        $redirect_clear_log = 'No';
    }
    if (isset($icarus_Main_Settings['redirect_permalink'])) {
        $redirect_permalink = $icarus_Main_Settings['redirect_permalink'];
    } else {
        $redirect_permalink = '';
    }
    if (isset($icarus_Main_Settings['redirect_trashed'])) {
        $redirect_trashed = $icarus_Main_Settings['redirect_trashed'];
    } else {
        $redirect_trashed = '';
    }
    if (isset($icarus_Main_Settings['redirect_drafted'])) {
        $redirect_drafted = $icarus_Main_Settings['redirect_drafted'];
    } else {
        $redirect_drafted = '';
    }
    if (isset($icarus_Main_Settings['redirect_loggedin'])) {
        $redirect_loggedin = $icarus_Main_Settings['redirect_loggedin'];
    } else {
        $redirect_loggedin = '';
    }
?>
<script>
                var icarus_admin_json = {
                    icarus_enabled: '<?php
    echo $icarus_enabled;
?>',
                    redirect_enable: '<?php
    echo $redirect_enable;
?>',
                    redirect_404_enable: '<?php
    echo $redirect_404_enable;
?>',
                    redirect_404_link: '<?php
    echo $redirect_404_link;
?>',
                    redirect_random: '<?php
    echo $redirect_random;
?>',
                    redirect_random_url: '<?php
    echo $redirect_random_url;
?>',
                    start_time: '<?php
    echo $start_time;
?>',
                    end_time: '<?php
    echo $end_time;
?>',
                    start_date: '<?php
    echo $start_date;
?>',
                    end_date: '<?php
    echo $end_date;
?>',
                    redirect_time_based: '<?php
    echo $redirect_time_based;
?>',
                    redirect_enable_referrer: '<?php
    echo $redirect_enable_referrer;
?>',
                    redirect_referrer_link: '<?php
    echo $redirect_referrer_link;
?>',
                    redirect_enable_username: '<?php
    echo $redirect_enable_username;
?>',
                    redirect_username: '<?php
    echo $redirect_username;
?>',
                    redirect_enable_os: '<?php
    echo $redirect_enable_os;
?>',
                    redirect_os: '<?php
    echo $redirect_os;
?>',
                    redirect_enable_log: '<?php
    echo $redirect_enable_log;
?>',
                    redirect_logout_link: '<?php
    echo $redirect_logout_link;
?>',
                    redirect_logout: '<?php
    echo $redirect_logout;
?>',
                    redirect_login_link: '<?php
    echo $redirect_login_link;
?>',
                    redirect_login: '<?php
    echo $redirect_login;
?>',
                    redirect_maintenance_name: '<?php
    echo $redirect_maintenance_name;
?>',
                    redirect_maintenance_title: '<?php
    echo $redirect_maintenance_title;
?>',
                    redirect_maintenance: '<?php
    echo $redirect_maintenance;
?>',
                    redirect_maintenance_style: '<?php
    echo $redirect_maintenance_style;
?>',
                    redirect_maintenance_text_color: '<?php
    echo $redirect_maintenance_text_color;
?>',
                    redirect_maintenance_title_color: '<?php
    echo $redirect_maintenance_title_color;
?>',
                    redirect_attachment: '<?php
    echo $redirect_attachment;
?>',
                    redirect_comment_link: '<?php
    echo $redirect_comment_link;
?>',
                    redirect_comment: '<?php
    echo $redirect_comment;
?>',
                    redirect_adblock_link: '<?php
    echo $redirect_adblock_link;
?>',
                    redirect_adblock: '<?php
    echo $redirect_adblock;
?>',
                    redirect_http: '<?php
    echo $redirect_http;
?>',
                    redirect_www: '<?php
    echo $redirect_www;
?>',
                    redirect_clear_log: '<?php
    echo $redirect_clear_log;
?>',
                    redirect_permalink: '<?php
    echo $redirect_permalink;
?>',
                    redirect_trashed: '<?php
    echo $redirect_trashed;
?>',
                    redirect_drafted: '<?php
    echo $redirect_drafted;
?>',
                    redirect_loggedin: '<?php
    echo $redirect_loggedin;
?>'
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#redirect_random').is(":checked"))
        {            
            jQuery(".hideRand").show();
        }
        else
        {
            jQuery(".hideRand").hide();
        }
        if(jQuery('#redirect_404_enable').is(":checked"))
        {            
            jQuery(".hide404").show();
        }
        else
        {
            jQuery(".hide404").hide();
        }
        if(jQuery('#redirect_login').is(":checked"))
        {            
            jQuery(".hideLogin").show();
        }
        else
        {
            jQuery(".hideLogin").hide();
        }
        if(jQuery('#redirect_logout').is(":checked"))
        {            
            jQuery(".hideLogout").show();
        }
        else
        {
            jQuery(".hideLogout").hide();
        }
        if(jQuery('#redirect_maintenance').is(":checked"))
        {            
            jQuery(".hideMaintenance").show();
        }
        else
        {
            jQuery(".hideMaintenance").hide();
        }
        if(jQuery('#redirect_time_based').is(":checked"))
        {            
            jQuery(".hideTime").show();
        }
        else
        {
            jQuery(".hideTime").hide();
        }
        if(jQuery('#redirect_enable_os').is(":checked"))
        {            
            jQuery(".hideOs").show();
        }
        else
        {
            jQuery(".hideOs").hide();
        }
        if(jQuery('#redirect_enable_referrer').is(":checked"))
        {            
            jQuery(".hideRef").show();
        }
        else
        {
            jQuery(".hideRef").hide();
        }
        if(jQuery('#redirect_enable_username').is(":checked"))
        {            
            jQuery(".hideUser").show();
        }
        else
        {
            jQuery(".hideUser").hide();
        }
        if(jQuery('#redirect_comment').is(":checked"))
        {            
            jQuery(".hideComment").show();
        }
        else
        {
            jQuery(".hideComment").hide();
        }
        if(jQuery('#redirect_adblock').is(":checked"))
        {            
            jQuery(".hideAdblock").show();
        }
        else
        {
            jQuery(".hideAdblock").hide();
        }
    }
    window.onload = mainChanged;
</script>
<div ng-app="icasettingsApp" ng-controller="icasettingsController" ng-cloak ng-init="initialized()">
<script type="text/javascript" >
                        function saveRedirects()
                        {                       
                            var data = {
                                action: 'icarus_my_action'
                            };
                            jQuery.post(ajaxurl, data, function(response) {
                                var hiddenElement = document.createElement('a');
                                hiddenElement.href = 'data:attachment/text,' + encodeURI(response);
                                hiddenElement.target = '_blank';
                                hiddenElement.download = 'redirects.dat';
                                hiddenElement.click();
                            });
                        }
                        </script>
<script>
				jQuery(document).ready(function(){
					jQuery('span.wpicarus-delete').html('X').css({'color':'red','cursor':'pointer'}).click(function(){
						var confirm_delete = confirm('Delete This Redirect?');
						if (confirm_delete) {
							jQuery(this).parent().parent().remove();
							jQuery('#myForm').submit();						
						}
					});
				});
			</script>
<div class="icarus_redirects">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Icarus All In One Page Redirect Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Icarus Plugin. This acts like a main switch.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="icarus_enabled" name="icarus_Main_Settings[icarus_enabled]" onChange="mainChanged()" <?php
    if ($icarus_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="icarus_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <h3><b>Plugin Features:</b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "These features act separately from the rules defined bellow. Enable or disable them at will.";
?>
                        </div>
                    </div></h3>
                    <table><tr><td style="min-width:150px">
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow only registered and logged in users on your website? This will redirect all traffic that is from non-logged in users to the WordPress login page.";
?>
                        </div>
                    </div>
                    <b>Redirect Not Logged In Users to WordPress's Login Page:&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_loggedin" name="icarus_Main_Settings[redirect_loggedin]" <?php
    if ($redirect_loggedin == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Automatically Add Redirect Rule on Post Permalink Change' feature? This will automatically add a rule and will redirect the old post permalink to the new permalink that you have set for the post.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Redirect Rule on Post Permalink Change:&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_permalink" name="icarus_Main_Settings[redirect_permalink]" <?php
    if ($redirect_permalink == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Automatically Add Redirect Rule for Trashed Posts' feature? This will automatically add a rule and will redirect the trashed post permalink to your home page URL.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Redirect Rule for Trashed Posts:&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_trashed" name="icarus_Main_Settings[redirect_trashed]" <?php
    if ($redirect_trashed == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Automatically Add Redirect Rule for Drafted Posts' feature? This will automatically add a rule and will redirect the drafted post permalink to your home page URL.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Redirect Rule for Drafted Posts:&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_drafted" name="icarus_Main_Settings[redirect_drafted]" <?php
    if ($redirect_drafted == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <hr/></td><td><hr/></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Extended 404 Nearest Match Redirect' feature? This will enable and extend WordPress's build in 'Nearest Match Redirect' feature, making it search, beside posts, also in categories, tags and pages.";
?>
                        </div>
                    </div>
                    <b>Enable 'Extended 404 Nearest Match Redirect':&nbsp;&nbsp;</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_enable" name="icarus_Main_Settings[redirect_enable]" <?php
    if ($redirect_enable == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable '404 Page' redirect feature? This will disable the build-in 404 error page feature and will redirect all users who entered an invalid link, to a predefined URL.";
?>
                        </div>
                    </div>
                    <b>Enable '404 Page Not Found' Redirect:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_404_enable" name="icarus_Main_Settings[redirect_404_enable]" onclick="mainChanged()" <?php
    if ($redirect_404_enable == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hide404">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where 404 not found page errors will be redirected. Here you can set a custom 'Page Not Found' page or simply just your home page.";
?>
                        </div>
                    </div>
                    <b>'404 Page Not Found' Redirect Link:</b>
                    
                    </td><td>
                    <div class="hide404">
                    <input type="url" class="textIn" validator="url" name="icarus_Main_Settings[redirect_404_link]" ng-model="settings.redirect_404_link" >
                    </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Random Post' feature? If you enable this feature, this plugin will generate a redirect rule adress, where, users will be given every time, at every visit, one random post. A great feature, for making your webpage visits more diverse. Note that this feature is not affected by the timing options set bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Random Post' Generator Redirect:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_random" name="icarus_Main_Settings[redirect_random]" onclick="mainChanged()" <?php
    if ($redirect_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideRand">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
<?php
    echo "The link of the random post generator. Enter here the address where the 'Random Post' will be found.";
?>
                        </div>
                    </div>
                    <b>Random Post Generator Link:</b>
                    
                    </td><td>
                    <div class="hideRand">
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_random_url]" pattern="[/][^/].*" ng-model="settings.redirect_random_url" >
                    </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Login Redirect' feature? This feature will redirect your users after a successful login to a predefined link.";
?>
                        </div>
                    </div>
                    <b>Enable 'Login Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_login" name="icarus_Main_Settings[redirect_login]" onclick="mainChanged()" <?php
    if ($redirect_login == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class='hideLogin'>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where users will be redirected after succesful login. Please note that this can be only an internal webpage, otherwise login feature will not function.";
?>
                        </div>
                    </div>
                    <b>'Login Redirect' Link:</b>
                    
                    </td><td>
                    <div class='hideLogin'>
                    <input type="text" class="textIn" placeholder="<?php echo get_home_url();?>" name="icarus_Main_Settings[redirect_login_link]" pattern="^<?php echo strtr(get_home_url(), array ('/' => '\/'));?>(.*)" ng-model="settings.redirect_login_link">
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Logout Redirect' feature? This feature will redirect your users after a successful logout to a predefined link.";
?>
                        </div>
                    </div>
                    <b>Enable 'Logout Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_logout" name="icarus_Main_Settings[redirect_logout]" onclick="mainChanged()" <?php
    if ($redirect_logout == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class='hideLogout'>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where users will be redirected after succesful logout. This can be any link from the web.";
?>
                        </div>
                    </div>
                    <b>'Logout Redirect' Link:</b>
                    
                    </td><td>
                    <div class='hideLogout'>
                    <input type="url" class="textIn" validator="url" name="icarus_Main_Settings[redirect_logout_link]" ng-model="settings.redirect_logout_link" >
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature makes attachment pages redirects (301 permanent redirect) to post parent if any. If not, redirects (302 temporal redirect) to home page. Note that this feature is not affected by the timing options set bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Attachment Page Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_attachment" name="icarus_Main_Settings[redirect_attachment]" onclick="mainChanged()" <?php
    if ($redirect_attachment == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Comment' feature? Redirect commenters who just made their first comment (and only the first comment on entire blog!) to a page of your choice. On this page, you could thank them for commenting and ask them to subscribe to your blog or like you on Facebook. Note that this feature is not affected by the timing options set bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Comment Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_comment" name="icarus_Main_Settings[redirect_comment]" onclick="mainChanged()" <?php
    if ($redirect_comment == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class='hideComment'>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where users will be redirected after their first comment. This can be any link from the web.";
?>
                        </div>
                    </div>
                    <b>'Comment Redirect' Link:</b>
                    
                    </td><td>
                    <div class='hideComment'>
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_comment_link]" ng-model="settings.redirect_comment_link">
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Adblock Redirect' feature? Redirect users who have any kind of Adblock extension installed to a specific page you defined. Works absolutely for any kind of adblock browser extension.";
?>
                        </div>
                    </div>
                    <b>Enable 'Adblock Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_adblock" name="icarus_Main_Settings[redirect_adblock]" onclick="mainChanged()" <?php
    if ($redirect_adblock == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class='hideAdblock'>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link where users with adblock detected will be redirected to.";
?>
                        </div>
                    </div>
                    <b>'Adblock Redirect' Link:</b>
                    
                    </td><td>
                    <div class='hideAdblock'>
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_adblock_link]" ng-model="settings.redirect_adblock_link">
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This will redirect all HTTP traffic to HTTPS, or vice versa. Warning! Enable this only if you have HTTPS protocol enabled on your site, otherwise this feature will break your site functionality!";
?>
                        </div>
                    </div>
                    <b>'HTTP/HTTPS' Redirect:</b>
                    
                    </td><td>
                    <select name="icarus_Main_Settings[redirect_http]" ng-model="settings.redirect_http" style="width:100px;max-width:180px;">
                          <option value="No" selected>No Redirect</option>
                          <option value="Https">Force HTTPS</option>
                          <option value="Http">Force HTTP</option>
                    </select>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This will redirect all WWW traffic to non-www, or vice versa. Warning! Enable this only if you know that the version you select is functional, otherwise this feature will break your site functionality!";
?>
                        </div>
                    </div>
                    <b>'www/non-www' Redirect:</b>
                    
                    </td><td>
                    <select name="icarus_Main_Settings[redirect_www]" ng-model="settings.redirect_www" style="width:100px;max-width:180px;">
                          <option value="No" selected>No Redirect</option>
                          <option value="www">Force www</option>
                          <option value="no-www">Force non-www</option>
                    </select>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Maintenance Mode' feature? Maintenance mode page will be displayed only to users who are not logged in on your site or to users who do not have administrative priviledges. If you want to test it, you must log out from WordPress! This can also be configured as a 'Coming Soon' Page for future website release.";
?>
                        </div>
                    </div>
                    <b>Enable 'Maintenance Mode':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_maintenance" name="icarus_Main_Settings[redirect_maintenance]" onclick="mainChanged()" <?php
    if ($redirect_maintenance == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideMaintenance">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The page title to be displayed on the maintenance mode page. This should be something like 'Maintance Mode' or 'Coming soon'.";
?>
                        </div>
                    </div>
                    <b>'Maintenance Mode' Page Title:</b>
                    
                    </td><td>
                    <div class="hideMaintenance">
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_maintenance_title]" ng-model="settings.redirect_maintenance_title">
        </div></div>
        </td></tr><tr><td>
        <div class="hideMaintenance">
                    <div class="color_div">
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the title of your 'Maintenance Mode' page. Select it with the provided color picker tool, according to you selected page style color bellow.";
?>
                        </div>
                    </div>
                    <b>'Maintenance Mode' Title Color:</b>
                    </div>
                    </td><td>
                    <div class="hideMaintenance">
                    <input type="color" name="icarus_Main_Settings[redirect_maintenance_title_color]" ng-model="settings.redirect_maintenance_title_color">
                    </div>
                    
        </div>
        </td></tr><tr><td>
        <div class="hideMaintenance">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be displayed on the maintenance mode page. This should be something like 'We are currently under maintance. Don't forget to check back soon, we will wait you with cool new functionalities! Note that characters like ' or & will appear odd after you save the configuration, but it is normal (characters are escaped, but content on your site will appear normal).";
?>
                        </div>
                    </div>
                    <b>'Maintenance Mode' Page Text:</b>
                    
                    </td><td>
                    <div class="hideMaintenance">
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_maintenance_name]" ng-model="settings.redirect_maintenance_name">
        </div></div>
        </td></tr><tr><td>
        <div class="hideMaintenance">
                    <div class="color_div">
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the text of your 'Maintenance Mode' page. Select it with the provided color picker tool, according to you selected page style color bellow.";
?>
                        </div>
                    </div>
                    <b>'Maintenance Mode' Text Color:</b>
                    </div>
                    </td><td>
                    <div class="hideMaintenance">
                    <input type="color" name="icarus_Main_Settings[redirect_maintenance_text_color]" ng-model="settings.redirect_maintenance_text_color">
                    </div>
                    
        </div>
        </td></tr>
        <tr><td>
        <div class="hideMaintenance">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The style of the maintenance mode page. This will change mainly the backgorund image.";
?>
                        </div>
                    </div>
                    <b>'Maintenance Mode' Page Style:</b>
                    
                    </td><td>
                    <div class="hideMaintenance">
                    <select name="icarus_Main_Settings[redirect_maintenance_style]" ng-model="settings.redirect_maintenance_style">
                          <option value="Plain" selected>Plain</option>
                          <option value="White">White</option>
                          <option value="Black">Black</option>
                          <option value="Red">Red</option>
                          <option value="Green">Green</option>
                          <option value="Blue">Blue</option>
                          <option value="Yellow">Yellow</option>
                    </select>
        </div></div>
        </td></tr><tr><td>
        <h3><b>General Rules:</b></b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Note that these features affect the functionality of the rules defined bellow. Be sure to configure this options with caution.";
?>
                        </div>
                    </div></h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Time Based Redirect' feature? This feature will enable redirect features of this plugin (including 'Maintenance Mode'!) only inside the given time interval specified bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Time Based Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_time_based" name="icarus_Main_Settings[redirect_time_based]" onclick="mainChanged()"  <?php
    if ($redirect_time_based == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideTime">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "When to start redirecting? For this feature to work, both start time and end time MUST be set! Be sure you check the local server time before you set this rule.";
?>
                        </div>
                    </div>
                    <b>Time Based Redirect Start Time:</b>
                    
                    </td><td>
                    <div class="hideTime">
                    <input style="width: 80px;" name="icarus_Main_Settings[start_date]" type="text" id="start_date" ng-model="settings.start_date"  class="date" />
                    <input style="width: 50px;" name="icarus_Main_Settings[start_time]" type="text" id="start_time" ng-model="settings.start_time"  class="time" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/>
        </div></div>
        </td></tr><tr><td>
        <div class="hideTime">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "When to end redirecting? For this feature to work, both start time and end time MUST be set!  Be sure you check the local server time before you set this rule.";
?>
                        </div>
                    </div>
                    <b>Time Based Redirect End Time:</b>
                    
                    </td><td>
                    <div class="hideTime">
                    <input style="width: 80px;" name="icarus_Main_Settings[end_date]" type="text" id="end_date" ng-model="settings.end_date"  class="date" />
                    <input style="width: 50px;" name="icarus_Main_Settings[end_time]" type="text" id="end_time" ng-model="settings.end_time"  class="time" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/>
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Referrer Source' feature? If you enable this, redirect will be made only if the source of your traffic corresponds with the link specified bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'Referrer Source' Filtering:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_enable_referrer" name="icarus_Main_Settings[redirect_enable_referrer]" onclick="mainChanged()" <?php
    if ($redirect_enable_referrer == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideRef">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link from where the traffic should come. Here you should specify the link from where your traffic comes which should be redirected to the custom urls defined in the rules bellow.";
?>
                        </div>
                    </div>
                    <b>'Referrer Source' Link:</b>
                    
                    </td><td>
                    <div class="hideRef">
                    <input type="url" validator="url" class="textIn" name="icarus_Main_Settings[redirect_referrer_link]" ng-model="settings.redirect_referrer_link">
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'User Name Redirect' feature? This will redirect only the user defined in the textbox bellow. Note that if you want to include more referrer links, you shoul enter them all here, separated by comma.";
?>
                        </div>
                    </div>
                    <b>Enable 'User Name Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_enable_username" name="icarus_Main_Settings[redirect_enable_username]" onclick="mainChanged()" <?php
    if ($redirect_enable_username == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideUser">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The username who to redirect. Define here the username of the user who should be redirected. Note that if you want to define more users, you should enter them all here, separated by comma.";
?>
                        </div>
                    </div>
                    <b>'User Name Redirect' UserName:</b>
                    
                    </td><td>
                    <div class="hideUser">
                    <input type="text" class="textIn" name="icarus_Main_Settings[redirect_username]" ng-model="settings.redirect_username">
        </div></div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'OS Based Redirect' feature? The redirect will take place only if the OS of the user corresponds with the OS defined bellow.";
?>
                        </div>
                    </div>
                    <b>Enable 'OS Based Redirect':</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect_enable_os" name="icarus_Main_Settings[redirect_enable_os]" onclick="mainChanged()" <?php
    if ($redirect_enable_os == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideOs">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "What OS to redirect? Define here the OS that should be redirected by the rules bellow.";
?>
                        </div>
                    </div>
                    <b>'OS Based Redirect' Selected OS:</b>
                    </td><td>
                    <div class="hideOs">
                    <select name="icarus_Main_Settings[redirect_os]" ng-model="settings.redirect_os" style="width:100px;max-width:180px;">
                          <option value="All" selected>All</option>
                          <option value="All Windows">All Windows</option>
                          <option value="All Mac">All Mac</option>
                          <option value="All Apple">All Apple</option>
                          <option value="All Linux">All Linux</option>
                          <option value="iOs">iOs</option>
                          <option value="Android">Android</option>
                          <option value="Linux">Linux</option>
                          <option value="Windows 10">Windows 10</option>
                          <option value="Windows 8.1">Windows 8.1</option>
                          <option value="Windows 8">Windows 8</option>
                          <option value="Windows 7">Windows 7</option>
                          <option value="Windows Vista">Windows Vista</option>
                          <option value="Windows Server 2003/XP x64">Windows Server 2003/XP x64</option>
                          <option value="Windows XP">Windows XP</option>
                          <option value="Windows 2000">Windows 2000</option>
                          <option value="Windows ME">Windows ME</option>
                          <option value="Windows 98">Windows 98</option>
                          <option value="Windows 95">Windows 95</option>
                          <option value="Windows 3.11">Windows 3.11</option>
                          <option value="Mac OS X">Mac OS X</option>
                          <option value="Mac OS 9">Mac OS 9</option>
                          <option value="Ubuntu">Ubuntu</option>
                          <option value="iPhone">iPhone</option>
                          <option value="iPod">iPod</option>
                          <option value="iPad">iPad</option>
                          <option value="BlackBerry">BlackBerry</option>
                          <option value="Mobile">Mobile</option>
                    </select>
        </div></div>
        </td></tr><tr><td>
        <h3><b>Debug Features:</b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "There are some debugging features made to help you in the bug reporting process, in case you discover a bug and want to report it, so I can fix it in a future plugin version.";
?>
                        </div>
                    </div></h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to log full plugin activity? This should not be enabled only if instructed so by the plugin developer, or if you want to personally investigate the plugins functionality.";
?>
                        </div>
                    </div>
                    <b>Log Full Plugin Activity:</b>
                    </td><td>
                    <input type="checkbox" id="redirect_enable_log" name="icarus_Main_Settings[redirect_enable_log]" <?php
    if ($redirect_enable_log == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically clear logs after a predefined time?";
?>
                        </div>
                    </div>
                    <b>Automatically clear logs after:</b>
                    </td><td>
                    <select  name="icarus_Main_Settings[redirect_clear_log]" ng-model="settings.redirect_clear_log" style="width:100px;max-width:180px;">
                          <option value="No" selected>No Auto Log Clearing</option>
                          <option value="monthly">1 Month</option>
                          <option value="weekly">1 Week</option>
                          <option value="daily">1 Day</option>
                          <option value="twicedaily">12 Hours</option>
                          <option value="hourly">1 Hour</option>
                        </select>                   
        </div>
        </td></tr><tr><td>
        <p><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The date and time on your server. You should define your timing rules with this knowledge in your mind.";
?>
                        </div>
                    </div>&nbsp;<b>Local Server Time:</b></td><td> <input type="text" class="textIn" disabled value="<?php echo $date = date('m/d/Y h:ia', time());?>"></p></td></tr><tr><td>
        <h3><b>Defined Rules Manager:</b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here are listed the defined redirecting rules. Note that you can also use wildcards in your plugin rules (if you enable them).";
?>
                        </div>
                    </div></h3>
        </td></tr></table>
        <hr/>
        <div class="table-responsive">
                    <table class="responsive table" style="overflow-x:auto;">
				<thead>
					<tr>
						<th>URL<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The source URL from where you want to redirect your users. Note that this is the most important field in this table! Note that this field must contain only internal links (stating with /)! Leave this field blank to delete this redirection rule.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:20px;">*?<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable usage of wildcards in this rule? You can lear about wildcards and their usage <a href='http://ryanstutorials.net/linuxtutorial/wildcards.php'>here</a>.";
?>
                        </div>
                    </div></th>
						<th>Redirect<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Where do you want to redirect your users? You can also leave this field blank, for 404 like status codes. Leave blank to permanently disable this redirect rule.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:20px;">Del<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to delete this rule?";
?>
                        </div>
                    </div></th>
                        <th>Device<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the device type where this rule is applied.";
?>
                        </div>
                    </div></th>
                        <th>Login<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select user login related rules for your redirection.";
?>
                        </div>
                    </div></th>
                        <th style="min-width:84px;">IP<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert the IP adress which you want to redirect. Leave blank to disable.";
?>
                        </div>
                    </div></th>
                        <th>Country<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose users from which country should be redirected.";
?>
                        </div>
                    </div></th>
                        <th>Language<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose users with which language will be redirected. Note that the user must set explicitly their language in their system settings (default is English).";
?>
                        </div>
                    </div></th>
                        <th>Browser<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose the browser version you want to redirect";
?>
                        </div>
                    </div></th>
                        <th>Start<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose the start time when you want to enable your redirect. Note that the time is related where your Server is located. Also, note that the time interval you set here will trigger daily. Leave blank to disable.";
?>
                        </div>
                    </div></th>
                        <th>End<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose the end time when you want to disable your redirect. Note that the time is related where your Server is located. Also, note that the time interval you set here will trigger daily. Leave blank to disable.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:30px;" >Log<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to log when a redirect happens? You can see results in the 'View Logs' section of this plugin.";
?>
                        </div>
                    </div></th>
                        <th style="max-width:32px;" >Active<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable this<br/> plugin? You can deactivate<br/> any rule (you don't have<br/> to delete them to deactivate<br/> them).";
?>
                        </div>
                    </div></th>
                        <th>Type<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose the<br/> redirect type <br/>you want to<br/> apply for your<br/> rule. Recommended,<br/> for best SEO<br/> result is 301 redirect.<br/> Please do not <br/>select 403 or <br/>404 statuses, unless<br/> you know what you are doing.";
?>
                        </div>
                    </div></th>
					</tr>
				</thead>
				<tbody>
					<?php echo icarus_expand_redirects(); ?>
					<tr>
						<td style="min-width:100px;width:15%;text-align:center;vertical-align: middle;"><input type="text" pattern="[/][^/].*" placeholder="/yourlink.html" name="icarus_301_redirects[request][]" value="" style="width:99%;" /></td>
						<td style="max-width:20px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[wildcard][]" value="1" /></td>
                        <td style="min-width:100px;width:15%;text-align:center;vertical-align: middle;"><input type="url" validator="url" placeholder="http://www.yourRedirect.com" name="icarus_301_redirects[destination][]" value="" style="width:99%;"/></td>
						<td style="max-width:20px;text-align: center;" ><span style="max-width:20px;" class="wpicarus-delete"></span></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[device][]">
                          <option value="All" selected>All</option>
                          <option value="Mobile">Mobile</option>
                          <option value="Tablet">Tablet</option>
                          <option value="Desktop">Desktop</option>
                          <option value="Bot">Bot</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[login][]">
                          <option value="All" selected>All</option>
                          <option value="LoggedIn">LoggedIn</option>
                          <option value="NotLoggedIn">NotLoggedIn</option>
                          <option value="Admin">Admin</option>
                          <option value="NotAdmin">NotAdmin</option>
                        </select></td>
                        <td style="min-width:84px;width:84px;text-align:center;vertical-align: middle;"><input type="text" placeholder="0.0.0.0" pattern="^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$" name="icarus_301_redirects[ip][]" value="" style="width:99%;" /></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[country][]">
                            <option value="ALL">ALL</option>
                            <option value="AF">Afghanistan</option>
                            <option value="AX">Åland Islands</option>
                            <option value="AL">Albania</option>
                            <option value="DZ">Algeria</option>
                            <option value="AS">American Samoa</option>
                            <option value="AD">Andorra</option>
                            <option value="AO">Angola</option>
                            <option value="AI">Anguilla</option>
                            <option value="AQ">Antarctica</option>
                            <option value="AG">Antigua and Barbuda</option>
                            <option value="AR">Argentina</option>
                            <option value="AM">Armenia</option>
                            <option value="AW">Aruba</option>
                            <option value="AU">Australia</option>
                            <option value="AT">Austria</option>
                            <option value="AZ">Azerbaijan</option>
                            <option value="BS">Bahamas</option>
                            <option value="BH">Bahrain</option>
                            <option value="BD">Bangladesh</option>
                            <option value="BB">Barbados</option>
                            <option value="BY">Belarus</option>
                            <option value="BE">Belgium</option>
                            <option value="BZ">Belize</option>
                            <option value="BJ">Benin</option>
                            <option value="BM">Bermuda</option>
                            <option value="BT">Bhutan</option>
                            <option value="BO">Bolivia, Plurinational State of</option>
                            <option value="BQ">Bonaire, Sint Eustatius and Saba</option>
                            <option value="BA">Bosnia and Herzegovina</option>
                            <option value="BW">Botswana</option>
                            <option value="BV">Bouvet Island</option>
                            <option value="BR">Brazil</option>
                            <option value="IO">British Indian Ocean Territory</option>
                            <option value="BN">Brunei Darussalam</option>
                            <option value="BG">Bulgaria</option>
                            <option value="BF">Burkina Faso</option>
                            <option value="BI">Burundi</option>
                            <option value="KH">Cambodia</option>
                            <option value="CM">Cameroon</option>
                            <option value="CA">Canada</option>
                            <option value="CV">Cape Verde</option>
                            <option value="KY">Cayman Islands</option>
                            <option value="CF">Central African Republic</option>
                            <option value="TD">Chad</option>
                            <option value="CL">Chile</option>
                            <option value="CN">China</option>
                            <option value="CX">Christmas Island</option>
                            <option value="CC">Cocos (Keeling) Islands</option>
                            <option value="CO">Colombia</option>
                            <option value="KM">Comoros</option>
                            <option value="CG">Congo</option>
                            <option value="CD">Congo, the Democratic Republic of the</option>
                            <option value="CK">Cook Islands</option>
                            <option value="CR">Costa Rica</option>
                            <option value="CI">Côte d'Ivoire</option>
                            <option value="HR">Croatia</option>
                            <option value="CU">Cuba</option>
                            <option value="CW">Curaçao</option>
                            <option value="CY">Cyprus</option>
                            <option value="CZ">Czech Republic</option>
                            <option value="DK">Denmark</option>
                            <option value="DJ">Djibouti</option>
                            <option value="DM">Dominica</option>
                            <option value="DO">Dominican Republic</option>
                            <option value="EC">Ecuador</option>
                            <option value="EG">Egypt</option>
                            <option value="SV">El Salvador</option>
                            <option value="GQ">Equatorial Guinea</option>
                            <option value="ER">Eritrea</option>
                            <option value="EE">Estonia</option>
                            <option value="ET">Ethiopia</option>
                            <option value="FK">Falkland Islands (Malvinas)</option>
                            <option value="FO">Faroe Islands</option>
                            <option value="FJ">Fiji</option>
                            <option value="FI">Finland</option>
                            <option value="FR">France</option>
                            <option value="GF">French Guiana</option>
                            <option value="PF">French Polynesia</option>
                            <option value="TF">French Southern Territories</option>
                            <option value="GA">Gabon</option>
                            <option value="GM">Gambia</option>
                            <option value="GE">Georgia</option>
                            <option value="DE">Germany</option>
                            <option value="GH">Ghana</option>
                            <option value="GI">Gibraltar</option>
                            <option value="GR">Greece</option>
                            <option value="GL">Greenland</option>
                            <option value="GD">Grenada</option>
                            <option value="GP">Guadeloupe</option>
                            <option value="GU">Guam</option>
                            <option value="GT">Guatemala</option>
                            <option value="GG">Guernsey</option>
                            <option value="GN">Guinea</option>
                            <option value="GW">Guinea-Bissau</option>
                            <option value="GY">Guyana</option>
                            <option value="HT">Haiti</option>
                            <option value="HM">Heard Island and McDonald Islands</option>
                            <option value="VA">Holy See (Vatican City State)</option>
                            <option value="HN">Honduras</option>
                            <option value="HK">Hong Kong</option>
                            <option value="HU">Hungary</option>
                            <option value="IS">Iceland</option>
                            <option value="IN">India</option>
                            <option value="ID">Indonesia</option>
                            <option value="IR">Iran, Islamic Republic of</option>
                            <option value="IQ">Iraq</option>
                            <option value="IE">Ireland</option>
                            <option value="IM">Isle of Man</option>
                            <option value="IL">Israel</option>
                            <option value="IT">Italy</option>
                            <option value="JM">Jamaica</option>
                            <option value="JP">Japan</option>
                            <option value="JE">Jersey</option>
                            <option value="JO">Jordan</option>
                            <option value="KZ">Kazakhstan</option>
                            <option value="KE">Kenya</option>
                            <option value="KI">Kiribati</option>
                            <option value="KP">Korea, Democratic People's Republic of</option>
                            <option value="KR">Korea, Republic of</option>
                            <option value="KW">Kuwait</option>
                            <option value="KG">Kyrgyzstan</option>
                            <option value="LA">Lao People's Democratic Republic</option>
                            <option value="LV">Latvia</option>
                            <option value="LB">Lebanon</option>
                            <option value="LS">Lesotho</option>
                            <option value="LR">Liberia</option>
                            <option value="LY">Libya</option>
                            <option value="LI">Liechtenstein</option>
                            <option value="LT">Lithuania</option>
                            <option value="LU">Luxembourg</option>
                            <option value="MO">Macao</option>
                            <option value="MK">Macedonia, the former Yugoslav Republic of</option>
                            <option value="MG">Madagascar</option>
                            <option value="MW">Malawi</option>
                            <option value="MY">Malaysia</option>
                            <option value="MV">Maldives</option>
                            <option value="ML">Mali</option>
                            <option value="MT">Malta</option>
                            <option value="MH">Marshall Islands</option>
                            <option value="MQ">Martinique</option>
                            <option value="MR">Mauritania</option>
                            <option value="MU">Mauritius</option>
                            <option value="YT">Mayotte</option>
                            <option value="MX">Mexico</option>
                            <option value="FM">Micronesia, Federated States of</option>
                            <option value="MD">Moldova, Republic of</option>
                            <option value="MC">Monaco</option>
                            <option value="MN">Mongolia</option>
                            <option value="ME">Montenegro</option>
                            <option value="MS">Montserrat</option>
                            <option value="MA">Morocco</option>
                            <option value="MZ">Mozambique</option>
                            <option value="MM">Myanmar</option>
                            <option value="NA">Namibia</option>
                            <option value="NR">Nauru</option>
                            <option value="NP">Nepal</option>
                            <option value="NL">Netherlands</option>
                            <option value="NC">New Caledonia</option>
                            <option value="NZ">New Zealand</option>
                            <option value="NI">Nicaragua</option>
                            <option value="NE">Niger</option>
                            <option value="NG">Nigeria</option>
                            <option value="NU">Niue</option>
                            <option value="NF">Norfolk Island</option>
                            <option value="MP">Northern Mariana Islands</option>
                            <option value="NO">Norway</option>
                            <option value="OM">Oman</option>
                            <option value="PK">Pakistan</option>
                            <option value="PW">Palau</option>
                            <option value="PS">Palestinian Territory, Occupied</option>
                            <option value="PA">Panama</option>
                            <option value="PG">Papua New Guinea</option>
                            <option value="PY">Paraguay</option>
                            <option value="PE">Peru</option>
                            <option value="PH">Philippines</option>
                            <option value="PN">Pitcairn</option>
                            <option value="PL">Poland</option>
                            <option value="PT">Portugal</option>
                            <option value="PR">Puerto Rico</option>
                            <option value="QA">Qatar</option>
                            <option value="RE">Réunion</option>
                            <option value="RO">Romania</option>
                            <option value="RU">Russian Federation</option>
                            <option value="RW">Rwanda</option>
                            <option value="BL">Saint Barthélemy</option>
                            <option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
                            <option value="KN">Saint Kitts and Nevis</option>
                            <option value="LC">Saint Lucia</option>
                            <option value="MF">Saint Martin (French part)</option>
                            <option value="PM">Saint Pierre and Miquelon</option>
                            <option value="VC">Saint Vincent and the Grenadines</option>
                            <option value="WS">Samoa</option>
                            <option value="SM">San Marino</option>
                            <option value="ST">Sao Tome and Principe</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="SN">Senegal</option>
                            <option value="RS">Serbia</option>
                            <option value="SC">Seychelles</option>
                            <option value="SL">Sierra Leone</option>
                            <option value="SG">Singapore</option>
                            <option value="SX">Sint Maarten (Dutch part)</option>
                            <option value="SK">Slovakia</option>
                            <option value="SI">Slovenia</option>
                            <option value="SB">Solomon Islands</option>
                            <option value="SO">Somalia</option>
                            <option value="ZA">South Africa</option>
                            <option value="GS">South Georgia and the South Sandwich Islands</option>
                            <option value="SS">South Sudan</option>
                            <option value="ES">Spain</option>
                            <option value="LK">Sri Lanka</option>
                            <option value="SD">Sudan</option>
                            <option value="SR">Suriname</option>
                            <option value="SJ">Svalbard and Jan Mayen</option>
                            <option value="SZ">Swaziland</option>
                            <option value="SE">Sweden</option>
                            <option value="CH">Switzerland</option>
                            <option value="SY">Syrian Arab Republic</option>
                            <option value="TW">Taiwan, Province of China</option>
                            <option value="TJ">Tajikistan</option>
                            <option value="TZ">Tanzania, United Republic of</option>
                            <option value="TH">Thailand</option>
                            <option value="TL">Timor-Leste</option>
                            <option value="TG">Togo</option>
                            <option value="TK">Tokelau</option>
                            <option value="TO">Tonga</option>
                            <option value="TT">Trinidad and Tobago</option>
                            <option value="TN">Tunisia</option>
                            <option value="TR">Turkey</option>
                            <option value="TM">Turkmenistan</option>
                            <option value="TC">Turks and Caicos Islands</option>
                            <option value="TV">Tuvalu</option>
                            <option value="UG">Uganda</option>
                            <option value="UA">Ukraine</option>
                            <option value="AE">United Arab Emirates</option>
                            <option value="GB">United Kingdom</option>
                            <option value="US">United States</option>
                            <option value="UM">United States Minor Outlying Islands</option>
                            <option value="UY">Uruguay</option>
                            <option value="UZ">Uzbekistan</option>
                            <option value="VU">Vanuatu</option>
                            <option value="VE">Venezuela, Bolivarian Republic of</option>
                            <option value="VN">Viet Nam</option>
                            <option value="VG">Virgin Islands, British</option>
                            <option value="VI">Virgin Islands, U.S.</option>
                            <option value="WF">Wallis and Futuna</option>
                            <option value="EH">Western Sahara</option>
                            <option value="YE">Yemen</option>
                            <option value="ZM">Zambia</option>
                            <option value="ZW">Zimbabwe</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[language][]">
                            <option value="ALL">ALL</option>
                            <option value="AF">Afrikanns</option>
                            <option value="SQ">Albanian</option>
                            <option value="AR">Arabic</option>
                            <option value="HY">Armenian</option>
                            <option value="EU">Basque</option>
                            <option value="BN">Bengali</option>
                            <option value="BG">Bulgarian</option>
                            <option value="CA">Catalan</option>
                            <option value="KM">Cambodian</option>
                            <option value="ZH">Chinese (Mandarin)</option>
                            <option value="HR">Croation</option>
                            <option value="CS">Czech</option>
                            <option value="DA">Danish</option>
                            <option value="NL">Dutch</option>
                            <option value="EN">English</option>
                            <option value="ET">Estonian</option>
                            <option value="FJ">Fiji</option>
                            <option value="FI">Finnish</option>
                            <option value="FR">French</option>
                            <option value="KA">Georgian</option>
                            <option value="DE">German</option>
                            <option value="EL">Greek</option>
                            <option value="GU">Gujarati</option>
                            <option value="HE">Hebrew</option>
                            <option value="HI">Hindi</option>
                            <option value="HU">Hungarian</option>
                            <option value="IS">Icelandic</option>
                            <option value="ID">Indonesian</option>
                            <option value="GA">Irish</option>
                            <option value="IT">Italian</option>
                            <option value="JA">Japanese</option>
                            <option value="JW">Javanese</option>
                            <option value="KO">Korean</option>
                            <option value="LA">Latin</option>
                            <option value="LV">Latvian</option>
                            <option value="LT">Lithuanian</option>
                            <option value="MK">Macedonian</option>
                            <option value="MS">Malay</option>
                            <option value="ML">Malayalam</option>
                            <option value="MT">Maltese</option>
                            <option value="MI">Maori</option>
                            <option value="MR">Marathi</option>
                            <option value="MN">Mongolian</option>
                            <option value="NE">Nepali</option>
                            <option value="NO">Norwegian</option>
                            <option value="FA">Persian</option>
                            <option value="PL">Polish</option>
                            <option value="PT">Portuguese</option>
                            <option value="PA">Punjabi</option>
                            <option value="QU">Quechua</option>
                            <option value="RO">Romanian</option>
                            <option value="RU">Russian</option>
                            <option value="SM">Samoan</option>
                            <option value="SR">Serbian</option>
                            <option value="SK">Slovak</option>
                            <option value="SL">Slovenian</option>
                            <option value="ES">Spanish</option>
                            <option value="SW">Swahili</option>
                            <option value="SV">Swedish </option>
                            <option value="TA">Tamil</option>
                            <option value="TT">Tatar</option>
                            <option value="TE">Telugu</option>
                            <option value="TH">Thai</option>
                            <option value="BO">Tibetan</option>
                            <option value="TO">Tonga</option>
                            <option value="TR">Turkish</option>
                            <option value="UK">Ukranian</option>
                            <option value="UR">Urdu</option>
                            <option value="UZ">Uzbek</option>
                            <option value="VI">Vietnamese</option>
                            <option value="CY">Welsh</option>
                            <option value="XH">Xhosa</option>
                        </select></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[browser][]">
                          <option value="All" selected>All</option>
                          <option value="IE">IE</option>
                          <option value="Edge">Edge</option>
                          <option value="Chrome">Chrome</option>
                          <option value="Firefox">Firefox</option>
                          <option value="Opera">Opera</option>
                          <option value="Safari">Safari</option>
                          <option value="Other">Other</option>
                        </select></td>
                        <td style="min-width:40px;width:40px;text-align:center;vertical-align: middle;"><input style="width: 50px;" name="icarus_301_redirects[time][]" type="text" id="basicExample" class="time" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/></td>
                        <td style="min-width:40px;width:40px;text-align:center;vertical-align: middle;"><input style="width: 50px;" name="icarus_301_redirects[end_time][]" type="text" id="endExample" class="time" pattern="(1[012]|[1-9]):[0-5][0-9](\\s)?(am|pm)"/></td>
                        <td style="max-width:30px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[logging][]" value="1" /></td>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;"><input type="checkbox" name="icarus_301_redirects[active][]" value="1" checked /></td>
                        <td style="width:6%;text-align:center;vertical-align: middle;"><select style="max-width:80px;" name="icarus_301_redirects[redirect][]">
                          <option value="301" selected>301</option>
                          <option value="302">302</option>
                          <option value="303">303</option>
                          <option value="307">307</option>
                          <option value="403">403</option>
                          <option value="404">404</option>
                        </select></td>
					</tr>
				</tbody>
			</table>
            <div><input type="button" onclick="saveRedirects()" value="Backup Rules To File" style="position: absolute; right: 40px;"/></div>
            </div>
            <br/><br/>
        <hr/>
        </div>
        </div>
        <script>
                jQuery(function() {
                    jQuery('#basicExample').timepicker();
                    jQuery('#endExample').timepicker();
                    jQuery('#start_time').timepicker();
                    jQuery('#end_time').timepicker();
                    jQuery('#start_date').datepicker();
                    jQuery('#end_date').datepicker();
                    <?php
                        echo icarus_expand_scripts();
                    ?>
                });
                jQuery("form").submit(function () {

                    var this_master = jQuery(this);

                    this_master.find('input[type="checkbox"]').each( function () {
                        var checkbox_this = jQuery(this);

                        if (checkbox_this.attr("id") !== "icarus_enabled" && checkbox_this.attr("id") !== "redirect_enable" && checkbox_this.attr("id") !== "redirect_loggedin" && checkbox_this.attr("id") !== "redirect_trashed" && checkbox_this.attr("id") !== "redirect_drafted" && checkbox_this.attr("id") !== "redirect_permalink" && checkbox_this.attr("id") !== "redirect_404_enable" && checkbox_this.attr("id") !== "redirect_random" && checkbox_this.attr("id") !== "redirect_time_based" && checkbox_this.attr("id") !== "redirect_enable_referrer" && checkbox_this.attr("id") !== "redirect_enable_username"  && checkbox_this.attr("id") !== "redirect_enable_os"  && checkbox_this.attr("id") !== "redirect_enable_log" && checkbox_this.attr("id") !== "redirect_login" && checkbox_this.attr("id") !== "redirect_logout" && checkbox_this.attr("id") !== "redirect_maintenance" && checkbox_this.attr("id") !== "redirect_attachment" && checkbox_this.attr("id") !== "redirect_comment" && checkbox_this.attr("id") !== "redirect_adblock")
                        {
                            if( checkbox_this.is(":checked") == true ) {
                                checkbox_this.attr('value','1');
                            } else {
                                checkbox_this.prop('checked',true);  
                                checkbox_this.attr('value','0');
                            }
                        }
                    })
                })
            </script>
<div>You can also use the following shortcodes: <b>[icarus_redirect]</b> and <b>[icarus_exit_link]</b>. <br/>Use [icarus_redirect] to automatically redirect users from a post or page (where you put the shortcode), to a predefined url, after a predefined timeout.<br/>The [icarus_exit_link] makes use of the 'Exit Strategy' feature of this plugin (details in plugin documentation). <br/> Example of shortcode usage: <b>[icarus_redirect url='http://WhereToRedirect.com' timeout='5']</b>. For details about the shortcodes, please see the plugin help file.</div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
?>